import { readFile, writeFile } from "node:fs/promises";

const css = (await readFile(new URL("../app/globals.css", import.meta.url), "utf8"))
  .replace(/^@import\s+["']tailwindcss["'];?\s*/m, "");
const javascript = (await readFile(new URL("./standalone-app.js", import.meta.url), "utf8"))
  .replaceAll("</script", "<\\/script");
const favicon = await readFile(new URL("../public/favicon.svg", import.meta.url), "utf8");
const faviconData = `data:image/svg+xml,${encodeURIComponent(favicon)}`;

const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Compare verified early-career quant roles and choose what to explore next.">
  <meta name="theme-color" content="#071b33">
  <link rel="icon" href="${faviconData}">
  <title>Quant Reality Check</title>
  <style>${css}</style>
</head>
<body>
  <div id="root"></div>
  <noscript>This website requires JavaScript to run the interactive reality check.</noscript>
  <script>${javascript}</script>
</body>
</html>`;

await writeFile(new URL("../outputs/index.html", import.meta.url), html, "utf8");
