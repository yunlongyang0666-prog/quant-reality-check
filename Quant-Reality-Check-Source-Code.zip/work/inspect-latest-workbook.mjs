import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const input = await FileBlob.load("/Users/loong/Downloads/111Catalyst_2026_Quant_Firm_Desk_Research_Expanded.xlsx");
const workbook = await SpreadsheetFile.importXlsx(input);
const sheets = JSON.parse((await workbook.inspect({ kind:"sheet", include:"id,name", maxChars:10000 })).ndjson);
console.log(JSON.stringify(sheets));
for (const item of sheets) {
  const name = item.name ?? item.sheetName;
  const inspection = await workbook.inspect({ kind:"table", sheetId:name, maxChars:30000, tableMaxRows:45, tableMaxCols:15, tableMaxCellChars:500 });
  console.log(`---SHEET:${name}---`);
  console.log(inspection.ndjson);
}
