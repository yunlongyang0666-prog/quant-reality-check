import { readFile, writeFile } from "node:fs/promises";

const raw = JSON.parse(await readFile(new URL("./expanded_roles_raw.json", import.meta.url), "utf8"));
const serialized = JSON.stringify(raw, null, 2);

const source = `export type RoleFamily = "Quantitative Trading" | "Quantitative Research" | "Software Engineering";
export type CompanyType = "Global market maker" | "Proprietary/diversified trading" | "Quantitative investment" | "Local/mid-sized firm" | "Other";
export type ApplicationStatus = "Open now" | "EOI / Talent Community" | "Program information only" | "Closed / no matching jobs" | "Unknown — verify";

type RawRole = {
  company: string; officialRoleTitle: string; level: string; location: string; statusTiming: string;
  responsibilities: string; candidateRequirements: string; priorFinanceRequired: string;
  boundaryObservation: string; officialSourceUrl: string;
};

export type Role = {
  id: string; company: string; companyType: CompanyType; companyScaleLabel: string;
  officialRoleTitle: string; normalizedRoleFamily: RoleFamily; level: string; location: string;
  workingRights: string; educationRequirements: string; responsibilities: string; requiredSkills: string;
  priorFinanceRequired: string; applicationStatus: ApplicationStatus; statusCheckedDate: string;
  officialSourceUrl: string; evidenceType: "Official JD" | "Official program page";
  confidence: string; boundaryObservation: string; statusCaveat: string;
  officialTitle: string; normalisedRoleFamily: RoleFamily; programYear: string; preferredSkills: string;
  degreeRequirements: string; graduationWindow: string; academicRequirement: string; workRights: string;
  financeBackgroundWording: string; sourceUrl: string; accessedDate: string;
  sourceType: "Official JD / company source"; limitations: string;
  evidenceKind: "Official JD" | "Official program page";
};

const NS = "Not stated";
const rawRoles: RawRole[] = ${serialized};

const companyMeta: Record<string,{companyType:CompanyType;companyScaleLabel:string;statusCheckedDate:string}> = {
  "Jane Street": { companyType:"Proprietary/diversified trading", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-21" },
  "Optiver": { companyType:"Global market maker", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-21" },
  "IMC Trading": { companyType:"Global market maker", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-21" },
  "Akuna Capital": { companyType:"Global market maker", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-21" },
  "Citadel Securities": { companyType:"Global market maker", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-22" },
  "Susquehanna (SIG)": { companyType:"Proprietary/diversified trading", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-22" },
  "DRW": { companyType:"Proprietary/diversified trading", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-22" },
  "Two Sigma": { companyType:"Quantitative investment", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-22" },
};

const slug = (value:string) => value.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"");
const familyFor = (title:string):RoleFamily => /software|engineering|developer/i.test(title) ? "Software Engineering" : /research/i.test(title) ? "Quantitative Research" : "Quantitative Trading";
const statusFor = (value:string):ApplicationStatus => value.startsWith("Open now") ? "Open now" : value.startsWith("Expression of Interest") ? "EOI / Talent Community" : value.startsWith("Program information") ? "Program information only" : value.startsWith("Closed") ? "Closed / no matching jobs" : "Unknown — verify";
const statements = (value:string, pattern:RegExp) => value.split(/(?<=[.;])/).map(x=>x.trim()).filter(x=>pattern.test(x)).join(" ") || NS;
const evidenceFor = (role:RawRole):"Official JD"|"Official program page" => /program information/i.test(role.level + role.statusTiming) || (role.company === "Optiver" && role.officialRoleTitle === "Software Engineer Internship") ? "Official program page" : "Official JD";

export const roles: Role[] = rawRoles.map((raw,index) => {
  const meta = companyMeta[raw.company];
  const applicationStatus = statusFor(raw.statusTiming);
  const normalizedRoleFamily = familyFor(raw.officialRoleTitle);
  const evidenceType = evidenceFor(raw);
  const workingRights = statements(raw.candidateRequirements,/work(ing)? rights|work authorization|citizenship|permanent residenc|\\bPR\\b|visa sponsorship/i);
  const educationRequirements = statements(raw.candidateRequirements,/bachelor|master|phd|degree|student|undergraduate|graduate|quantitative field|STEM/i);
  const graduationWindow = statements(raw.candidateRequirements,/graduat|penultimate|final-year|full-time availability/i);
  const academicRequirement = statements(raw.candidateRequirements,/High Distinction|GPA 3\\.5\\+/i);
  const statusCheckedDate = meta?.statusCheckedDate ?? "Not verified";
  const accessedDate = statusCheckedDate === "2026-08-21" ? "21 Aug 2026" : statusCheckedDate === "2026-08-22" ? "22 Aug 2026" : "Not verified";
  const statusCaveat = raw.company === "Optiver" && /2027/.test(raw.officialRoleTitle)
    ? `${raw.statusTiming}. Source conflict preserved: the reviewed title says 2027 while the page body still refers to the 2026 campaign.`
    : raw.statusTiming;
  return {
    id: \`role-\${index+1}-\${slug(raw.company)}-\${slug(raw.officialRoleTitle).slice(0,42)}\`,
    company: raw.company,
    companyType: meta?.companyType ?? "Other",
    companyScaleLabel: meta?.companyScaleLabel ?? "Not verified",
    officialRoleTitle: raw.officialRoleTitle,
    normalizedRoleFamily,
    level: raw.level,
    location: raw.location,
    workingRights,
    educationRequirements,
    responsibilities: raw.responsibilities,
    requiredSkills: raw.candidateRequirements,
    priorFinanceRequired: raw.priorFinanceRequired || NS,
    applicationStatus,
    statusCheckedDate,
    officialSourceUrl: raw.officialSourceUrl,
    evidenceType,
    confidence: applicationStatus === "Unknown — verify" ? "Official source contains a status conflict" : evidenceType === "Official program page" ? "Program verified; current vacancy not verified" : "Verified official company source",
    boundaryObservation: raw.boundaryObservation,
    statusCaveat,
    officialTitle: raw.officialRoleTitle,
    normalisedRoleFamily: normalizedRoleFamily,
    programYear: raw.statusTiming.match(/20\\d{2}/)?.[0] ?? NS,
    preferredSkills: NS,
    degreeRequirements: educationRequirements,
    graduationWindow,
    academicRequirement,
    workRights: workingRights,
    financeBackgroundWording: raw.priorFinanceRequired || NS,
    sourceUrl: raw.officialSourceUrl,
    accessedDate,
    sourceType: "Official JD / company source",
    limitations: applicationStatus === "Open now" ? "Official-source snapshot; verify current details before applying." : "Current availability must be verified before applying.",
    evidenceKind: evidenceType,
  };
});

export const companies = Array.from(new Set(roles.map(role=>role.company)));
export const dataStats = { companyCount: companies.length, roleCount: roles.length };

export const statusDefinitions: Record<ApplicationStatus,string> = {
  "Open now":"A specific reviewed role page provided an active application route when checked.",
  "EOI / Talent Community":"Interest can be registered, but this is not a current formal application.",
  "Program information only":"The program page exists; a current vacancy is not confirmed.",
  "Closed / no matching jobs":"The reviewed page indicated no current matching vacancy.",
  "Unknown — verify":"Official signals conflict or do not establish current availability.",
};

export const futureEvidence = { survey: [] as unknown[], interview: [] as unknown[] };
`;

await writeFile(new URL("../app/data.ts", import.meta.url), source, "utf8");
