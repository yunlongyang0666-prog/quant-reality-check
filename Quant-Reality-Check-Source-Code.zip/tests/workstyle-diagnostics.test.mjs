import assert from "node:assert/strict";
import test from "node:test";
import { resultForAnswers } from "../app/workstyle.js";

const expected = [
  ["ABCACB",6,0,0,"Signal Explorer",["Quantitative Research"]],
  ["BCACBA",0,6,0,"Market Navigator",["Quantitative Trading"]],
  ["CABBAC",0,0,6,"Systems Builder",["Software Engineering"]],
  ["ABCCBA",3,3,0,"Strategy Synthesizer",["Quantitative Research","Quantitative Trading"]],
  ["AAAAAA",2,2,2,"Open Explorer",["Quantitative Research","Quantitative Trading","Software Engineering"]],
  ["BBBBBB",2,2,2,"Open Explorer",["Quantitative Research","Quantitative Trading","Software Engineering"]],
  ["CCCCCC",2,2,2,"Open Explorer",["Quantitative Research","Quantitative Trading","Software Engineering"]],
];

test("development diagnostic table keeps shuffled mappings and transparent counts",()=>{
  const rows=expected.map(([answers,research,trading,systems,profile,directions])=>{
    const result=resultForAnswers(String(answers).split(""));
    const row={answers,research:result.scores.research/2,trading:result.scores.decision/2,systems:result.scores.systems/2,profile:result.config.en,directions:result.config.directions.join(" + ")};
    assert.deepEqual(row,{answers,research,trading,systems,profile,directions:directions.join(" + ")});
    return row;
  });
  console.table(rows);
});
