import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);
  return worker.fetch(new Request("http://localhost/", { headers: { accept: "text/html" } }), { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } }, { waitUntil() {}, passThroughOnException() {} });
}

test("renders the branded, dark landing experience", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  const html = await response.text();
  const [page, css] = await Promise.all([readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),readFile(new URL("../app/globals.css", import.meta.url), "utf8")]);
  assert.match(html, /<title>Quant Reality Check<\/title>/i);
  assert.match(html, /Explore the work/);
  assert.match(html, /behind the title/);
  assert.match(page, /dataStats\.roleCount/);
  assert.match(page, /WorkstyleExplorer/);
  assert.match(css, /--bg:#08111f/);
  assert.match(css, /overflow-x:hidden/);
  assert.match(css, /@media\(max-width:520px\)/);
  assert.doesNotMatch(html, /codex-preview|react-loading-skeleton/);
});

test("keeps 23 source-backed roles from eight companies and visible conflicts", async () => {
  const data = await readFile(new URL("../app/data.ts", import.meta.url), "utf8");
  assert.equal((data.match(/"officialRoleTitle":/g) ?? []).length, 23);
  for (const company of ["Jane Street","Optiver","IMC Trading","Akuna Capital","Citadel Securities","Susquehanna (SIG)","DRW","Two Sigma"]) assert.match(data,new RegExp(company.replace(/[()]/g,"\\$&")));
  assert.equal((data.match(/"officialSourceUrl": "https:\/\//g) ?? []).length, 23);
  assert.match(data, /title says 2027 while the page body still refers to the 2026 campaign/);
  assert.match(data, /9 vs 10 weeks/);
  assert.match(data, /Not stated/);
  assert.doesNotMatch(data, /workingRights = .*\? "No"/);
});

test("keeps research boundaries, source labels and comparison without scores", async () => {
  const [page, explorer, data] = await Promise.all([readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),readFile(new URL("../app/WorkstyleExplorer.tsx", import.meta.url), "utf8"),readFile(new URL("../app/data.ts", import.meta.url), "utf8")]);
  assert.match(page, /<b>17<\/b> anonymous survey responses/);
  assert.match(page, /2 live \+ 1 asynchronous written interview/);
  assert.match(page, /convenience-sample signals, not population estimates/);
  assert.match(page, /Similar titles, different work/);
  assert.match(page, /Different titles, similar tasks/);
  assert.match(explorer, /Worth exploring first/);
  assert.match(explorer, /not a personality diagnosis or a career verdict/);
  assert.match(explorer, /1080 × 1350/);
  assert.match(explorer, /navigator\.share/);
  assert.match(explorer, /Copy Link/);
  assert.match(data, /Official JD \/ company source/);
  assert.doesNotMatch(`${page}\n${explorer}`, /Best fit|Most suitable role|You are suited to|Career talent|Talent score|Match percentage|radar chart/i);
});

test("integrates career context, six scenarios and reality gap in eleven questions", async()=>{
  const [explorer,logic,css]=await Promise.all([readFile(new URL("../app/WorkstyleExplorer.tsx",import.meta.url),"utf8"),readFile(new URL("../app/workstyle.js",import.meta.url),"utf8"),readFile(new URL("../app/globals.css",import.meta.url),"utf8")]);
  assert.match(explorer,/Where are you currently in your quant-career exploration/);
  assert.match(explorer,/What role are you currently considering/);
  assert.match(explorer,/What is currently hardest for you to understand/);
  assert.match(explorer,/Which tasks do you currently expect your target role to involve most/);
  assert.match(explorer,/What are you currently spending most of your preparation time on/);
  assert.match(explorer,/11 questions/);
  assert.equal((explorer.match(/primary-result-section/g)??[]).length,8);
  for(const section of ["CURRENT WORKSTYLE SNAPSHOT","YOUR CURRENT CONTEXT","YOUR CURRENT ASSUMPTION","EVIDENCE-BASED REALITY CHECK","TASK FINGERPRINT","FIRM VARIATION","PREPARATION REALITY GAP","THREE NEXT ACTIONS"])assert.match(explorer,new RegExp(section));
  assert.match(explorer,/EXAMPLE RESULT — YOUR RESULT WILL VARY/);
  assert.match(explorer,/Compare these roles across firms/);
  assert.match(explorer,/Career stage, information gaps and preparation answers stay on this device/);
  assert.equal((logic.match(/illustration:"/g)??[]).length,7);
  for(const visual of ["art-signal","art-market","art-systems","art-synth","art-bridge","art-execution","art-prism"])assert.match(`${explorer}\n${css}`,new RegExp(visual));
});
