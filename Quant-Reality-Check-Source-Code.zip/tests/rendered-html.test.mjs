import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);
  return worker.fetch(new Request("http://localhost/", { headers: { accept: "text/html" } }), { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } }, { waitUntil() {}, passThroughOnException() {} });
}

test("renders the branded, dark landing experience", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  const html = await response.text();
  const [page, css] = await Promise.all([readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),readFile(new URL("../app/globals.css", import.meta.url), "utf8")]);
  assert.match(html, /<title>Quant Reality Check<\/title>/i);
  assert.match(html, /Explore the work/);
  assert.match(html, /behind the title/);
  assert.match(page, /dataStats\.roleCount/);
  assert.match(page, /WorkstyleExplorer/);
  assert.doesNotMatch(page, /CATALYST 2026 · FUNDAMENTUM/);
  assert.match(css, /--bg:#080e1a/);
  assert.match(css, /overflow-x:hidden/);
  assert.match(css, /main h1\[tabindex="-1"\]:focus\{outline:none\}/);
  assert.match(css, /@media\(max-width:520px\)/);
  assert.doesNotMatch(html, /codex-preview|react-loading-skeleton/);
});

test("keeps 23 source-backed roles from eight companies and visible conflicts", async () => {
  const data = await readFile(new URL("../app/data.ts", import.meta.url), "utf8");
  assert.equal((data.match(/"officialRoleTitle":/g) ?? []).length, 23);
  for (const company of ["Jane Street","Optiver","IMC Trading","Akuna Capital","Citadel Securities","Susquehanna (SIG)","DRW","Two Sigma"]) assert.match(data,new RegExp(company.replace(/[()]/g,"\\$&")));
  assert.equal((data.match(/"officialSourceUrl": "https:\/\//g) ?? []).length, 23);
  assert.match(data, /title says 2027 while the page body still refers to the 2026 campaign/);
  assert.match(data, /9 vs 10 weeks/);
  assert.match(data, /Not stated/);
  assert.doesNotMatch(data, /workingRights = .*\? "No"/);
});

test("keeps research boundaries, source labels and comparison without scores", async () => {
  const [page, explorer, data] = await Promise.all([readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),readFile(new URL("../app/WorkstyleExplorer.tsx", import.meta.url), "utf8"),readFile(new URL("../app/data.ts", import.meta.url), "utf8")]);
  assert.match(page, /<b>17<\/b> anonymous survey responses/);
  assert.match(page, /<b>3<\/b> qualitative perspectives/);
  assert.match(page, /2 live \+ 1 asynchronous written interview/);
  assert.match(page, /convenience-sample signals, not population estimates/);
  assert.match(page, /Similar titles, different work/);
  assert.match(page, /Different titles, similar tasks/);
  assert.match(explorer, /[Dd]irections? worth exploring first/);
  assert.match(explorer, /not a personality diagnosis or a career verdict/);
  assert.match(explorer, /1080 × 1350/);
  assert.match(explorer, /navigator\.share/);
  assert.match(explorer, /Copy link/);
  assert.match(explorer, /role="dialog" aria-modal="true"/);
  assert.match(explorer, /canvas\.width=1080;canvas\.height=1350/);
  assert.match(explorer, /document\.fonts\?\.ready/);
  assert.match(data, /Official JD \/ company source/);
  assert.doesNotMatch(`${page}\n${explorer}`, /Best fit|Most suitable role|You are suited to|Career talent|Talent score|Match percentage|radar chart/i);
});

test("integrates career context, six scenarios and reality gap in eleven questions", async()=>{
  const [explorer,logic,css]=await Promise.all([readFile(new URL("../app/WorkstyleExplorer.tsx",import.meta.url),"utf8"),readFile(new URL("../app/workstyle.js",import.meta.url),"utf8"),readFile(new URL("../app/globals.css",import.meta.url),"utf8")]);
  assert.match(explorer,/Where are you currently in your quant-career exploration/);
  assert.match(explorer,/What role are you currently considering/);
  assert.match(explorer,/What is currently hardest for you to understand/);
  assert.match(explorer,/Which tasks do you currently expect your target role to involve most/);
  assert.match(explorer,/What are you currently spending most of your preparation time on/);
  assert.match(explorer,/11 questions/);
  for(const section of ["Your Reality Check","WORKSTYLE SNAPSHOT","TARGET ALIGNMENT","REALITY GAP","PREPARATION GAP","Role evidence","Methodology","THREE NEXT ACTIONS"])assert.match(explorer,new RegExp(section));
  assert.match(explorer,/ROLE TRANSLATION MAP/);
  assert.match(explorer,/Balanced task signals/);
  assert.match(explorer,/No single task direction stands out from these six scenarios/);
  assert.match(explorer,/segmented-progress/);
  assert.equal((explorer.match(/<ScenarioVisual index=/g)??[]).length,1);
  assert.match(css,/@media\(prefers-reduced-motion:reduce\)/);
  assert.match(explorer,/Compare these roles across firms/);
  assert.match(explorer,/Context answers remain on this device/);
  assert.match(explorer,/Preference signals from six work scenarios—not measured ability/);
  for(const label of ["Unsure","Quantitative Trading","Quantitative Research","Software / Quantitative Engineering","Another quant-related role"])assert.match(`${explorer}\n${logic}`,new RegExp(label.replace(/[+/]/g,"\\$&")));
  for(const label of ["Day-to-day work","Math and coding requirements","Role differences","Fit with my background","Interview priorities","Recruitment timelines","Eligibility and location","Trustworthy sources"])assert.match(explorer,new RegExp(label));
  assert.match(explorer,/visibleTitle,subtitle,icon,storedValue,selected,onClick,index/);
  assert.doesNotMatch(explorer,/stageMeta\[index\]\?\.title\|\|gapTitles\[index\]\|\|option/);
  assert.match(explorer,/0 of 3 selected|informationGaps\.length\} of 3 selected/);
  assert.match(explorer,/Choose up to three\. Remove one selection to choose another\./);
  assert.match(explorer,/if\(selected\.length>=3\)return current/);
  assert.match(css,/answer-option>\.answer-copy\{min-width:0/);
  assert.match(css,/answer-option>i\{margin-left:auto\}/);
  assert.match(explorer,/Balanced task signals/);
  assert.equal((logic.match(/illustration:"/g)??[]).length,7);
  for(const visual of ["art-signal","art-market","art-systems","art-synth","art-bridge","art-execution","art-prism"])assert.match(`${explorer}\n${css}`,new RegExp(visual));
});

test("uses faceted multi-select filters with counts, chips and zero-result recovery",async()=>{
  const page=await readFile(new URL("../app/page.tsx",import.meta.url),"utf8");
  assert.match(page,/type FacetKey=/);
  assert.match(page,/countFor/);
  assert.match(page,/facetControl/);
  assert.match(page,/Advanced filters/);
  assert.match(page,/Active filters/);
  assert.match(page,/Clear all/);
  assert.match(page,/No reviewed role matches every selected condition/);
  assert.match(page,/No reviewed role contains/);
  assert.match(page,/of \{dataStats\.roleCount\} reviewed roles/);
  assert.match(page,/Selections stay visible even when filters hide a role/);
  assert.doesNotMatch(page,/Company scale/);
});
