import assert from "node:assert/strict";
import test from "node:test";
import { resultForAnswers } from "../app/workstyle.js";
import { actionPlan, stageContext, targetAlignment } from "../app/result-context.js";

const profiles={
  A:{answers:"ABCACB",careerStage:"I have only recently heard about quant careers.",target:"Unsure",informationGaps:["What different roles actually do day to day"],expectations:["Developing and validating models"],preparation:["Probability and mathematics"]},
  B:{answers:"BCACBA",careerStage:"I am preparing to apply.",target:"Quantitative Trading",informationGaps:["Recruitment stages and timelines"],expectations:["Making real-time risk decisions"],preparation:["Mental maths or trading games"]},
  C:{answers:"CABBAC",careerStage:"I am comparing different roles.",target:"Software / Quantitative Engineering",informationGaps:["Mathematics and programming requirements"],expectations:["Writing production software","Optimising latency and system performance"],preparation:["Python and data analysis"]},
  D:{answers:"AAAAAA",careerStage:"I am comparing different roles.",target:"Quantitative Research",informationGaps:["Interview preparation priorities"],expectations:["Developing and validating models","Writing production software"],preparation:["Statistics and machine learning"]},
};

test("four complete profiles produce deterministic context layers",()=>{
  const a=resultForAnswers(profiles.A.answers.split("")),b=resultForAnswers(profiles.B.answers.split("")),c=resultForAnswers(profiles.C.answers.split("")),d=resultForAnswers(profiles.D.answers.split(""));
  assert.equal(a.config.en,"Signal Explorer");assert.equal(b.config.en,"Market Navigator");assert.equal(c.config.en,"Systems Builder");assert.equal(d.config.en,"Open Explorer");
  assert.deepEqual(actionPlan(profiles.A),{stage:"early",gapType:"day-to-day",preparationType:"compare-preparation"});
  assert.deepEqual(actionPlan(profiles.B),{stage:"preparing",gapType:"timeline",preparationType:"compare-preparation"});
  assert.deepEqual(actionPlan(profiles.C),{stage:"comparing",gapType:"requirements",preparationType:"compare-preparation"});
  assert.deepEqual(actionPlan(profiles.D),{stage:"comparing",gapType:"interview",preparationType:"compare-preparation"});
  assert.equal(targetAlignment({target:profiles.A.target,directions:a.config.directions,primary:a.config.primary}).kind,"unsure");
  assert.match(targetAlignment({target:profiles.A.target,directions:a.config.directions,primary:a.config.primary}).text,/Start with the direction above/);
  assert.equal(targetAlignment({target:profiles.B.target,directions:b.config.directions,primary:b.config.primary}).kind,"aligned");
  assert.equal(targetAlignment({target:profiles.C.target,directions:c.config.directions,primary:c.config.primary}).kind,"aligned");
  assert.equal(targetAlignment({target:profiles.D.target,directions:d.config.directions,primary:d.config.primary}).kind,"balanced");
  assert.equal(stageContext(profiles.A.careerStage),"Early-stage explorer");
});

test("Open Explorer context changes without forcing a workstyle winner",()=>{
  const result=resultForAnswers("AAAAAA".split(""));
  const targeted={...profiles.D,plan:actionPlan(profiles.D),alignment:targetAlignment({target:profiles.D.target,directions:result.config.directions,primary:result.config.primary})};
  const unsure={...profiles.D,target:"Unsure",informationGaps:["What different roles actually do day to day"],plan:actionPlan({...profiles.D,target:"Unsure",informationGaps:["What different roles actually do day to day"]}),alignment:targetAlignment({target:"Unsure",directions:result.config.directions,primary:result.config.primary})};
  assert.equal(result.config.en,"Open Explorer");
  assert.deepEqual(result.scores,{research:4,decision:4,systems:4});
  assert.notDeepEqual({target:targeted.target,plan:targeted.plan,alignment:targeted.alignment},{target:unsure.target,plan:unsure.plan,alignment:unsure.alignment});
});
