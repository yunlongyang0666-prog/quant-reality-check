import assert from "node:assert/strict";
import test from "node:test";
import { resultConfigs, resultForAnswers, scenarios } from "../app/workstyle.js";

const cases = [
  ["ABCACB","signal-explorer"],
  ["BCACBA","market-navigator"],
  ["CABBAC","systems-builder"],
  ["ABCCBA","strategy-synthesizer"],
  ["ABCBAC","model-to-market-builder"],
  ["BCABAC","execution-architect"],
  ["AAAAAA","open-explorer"],
  ["BBBBBB","open-explorer"],
  ["CCCCCC","open-explorer"],
];

test("six neutral scenarios map deterministically to all seven result types",()=>{
  assert.equal(scenarios.length,6);
  for(const [answers,expected] of cases){
    const first=resultForAnswers(answers.split(""));
    const second=resultForAnswers(answers.split(""));
    assert.equal(first.id,expected);
    assert.deepEqual(first,second);
  }
});

test("every result has exactly three next actions and no target-role input",()=>{
  assert.equal(Object.keys(resultConfigs).length,7);
  for(const config of Object.values(resultConfigs)) assert.equal(config.actions.length,3);
  assert.equal(resultForAnswers.length,1);
});

test("display letters rotate across the required dimension sequence",()=>{
  assert.deepEqual(scenarios.map(scenario=>scenario.options.map(option=>option.dimension)),[
    ["research","decision","systems"],
    ["systems","research","decision"],
    ["decision","systems","research"],
    ["research","systems","decision"],
    ["systems","decision","research"],
    ["decision","research","systems"],
  ]);
});
