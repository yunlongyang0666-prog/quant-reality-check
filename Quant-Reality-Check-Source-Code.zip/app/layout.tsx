import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://quant-reality-check.yunlongyang0666.chatgpt.site"),
  title: "Quant Reality Check",
  description: "Compare verified early-career quant roles and choose what to explore next.",
  openGraph: {
    title: "Quant Reality Check",
    description: "Explore the work behind the title.",
    type: "website",
    images: [{ url: "/og.png", width: 1731, height: 909, alt: "Quant Reality Check — Explore the work behind the title." }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Quant Reality Check",
    description: "Explore the work behind the title.",
    images: ["/og.png"],
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
