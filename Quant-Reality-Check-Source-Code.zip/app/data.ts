export type RoleFamily = "Quantitative Trading" | "Quantitative Research" | "Software Engineering";
export type CompanyType = "Global market maker" | "Proprietary/diversified trading" | "Quantitative investment" | "Local/mid-sized firm" | "Other";
export type ApplicationStatus = "Open now" | "EOI / Talent Community" | "Program information only" | "Closed / no matching jobs" | "Unknown — verify";

type RawRole = {
  company: string; officialRoleTitle: string; level: string; location: string; statusTiming: string;
  responsibilities: string; candidateRequirements: string; priorFinanceRequired: string;
  boundaryObservation: string; officialSourceUrl: string;
};

export type Role = {
  id: string; company: string; companyType: CompanyType; companyScaleLabel: string;
  officialRoleTitle: string; normalizedRoleFamily: RoleFamily; level: string; location: string;
  workingRights: string; educationRequirements: string; responsibilities: string; requiredSkills: string;
  priorFinanceRequired: string; applicationStatus: ApplicationStatus; statusCheckedDate: string;
  officialSourceUrl: string; evidenceType: "Official JD" | "Official program page";
  confidence: string; boundaryObservation: string; statusCaveat: string;
  officialTitle: string; normalisedRoleFamily: RoleFamily; programYear: string; preferredSkills: string;
  degreeRequirements: string; graduationWindow: string; academicRequirement: string; workRights: string;
  financeBackgroundWording: string; sourceUrl: string; accessedDate: string;
  sourceType: "Official JD / company source"; limitations: string;
  evidenceKind: "Official JD" | "Official program page";
};

const NS = "Not stated";
const rawRoles: RawRole[] = [
  {
    "company": "Jane Street",
    "officialRoleTitle": "Quantitative Trader Internship, May–August",
    "level": "Internship",
    "location": "New York",
    "statusTiming": "Open now",
    "responsibilities": "Identify market signals; analyse and execute strategies; construct quantitative models; conduct statistical analysis; build trading intuition; participate in mock trading and refine strategies.",
    "candidateRequirements": "Strong quantitative thinker; clear communicator; collaborative; no specific degree/major required; general programming is a plus rather than a stated requirement.",
    "priorFinanceRequired": "No",
    "boundaryObservation": "Overlaps heavily with research through signals, modelling and statistical analysis.",
    "officialSourceUrl": "https://www.janestreet.com/join-jane-street/position/8617344002/"
  },
  {
    "company": "Jane Street",
    "officialRoleTitle": "Quantitative Researcher Internship, May–August",
    "level": "Internship",
    "location": "New York",
    "statusTiming": "Open now",
    "responsibilities": "Identify market signals; analyse large datasets; build and test models; create new trading strategies; apply statistical and ML techniques depending on the problem.",
    "candidateRequirements": "Intellectually curious; a strong programmer comfortable with Python; precise communicator and collaborator. Research experience is a plus. The role itself applies statistical and machine-learning techniques to market-data problems; finance background is not required.",
    "priorFinanceRequired": "No",
    "boundaryObservation": "Official JD explicitly states research, technology and trading lines are intentionally blurry.",
    "officialSourceUrl": "https://www.janestreet.com/join-jane-street/position/8498547002/"
  },
  {
    "company": "Jane Street",
    "officialRoleTitle": "Software Engineer Internship, May–August",
    "level": "Internship",
    "location": "Hong Kong",
    "statusTiming": "Open now",
    "responsibilities": "Learn and use OCaml and internal libraries/tools; may use Python; build maintainable production software; projects range from high-performance trading systems to programming-language design.",
    "candidateRequirements": "Strong programmer; intellectually curious; collaborative; eager to learn; no stated finance requirement.",
    "priorFinanceRequired": "No",
    "boundaryObservation": "Technology is a distinct department, but its systems are foundational to trading and research.",
    "officialSourceUrl": "https://www.janestreet.com/join-jane-street/position/8617298002/"
  },
  {
    "company": "Optiver",
    "officialRoleTitle": "Quantitative Trading Internship (Singapore) – 2027",
    "level": "Internship",
    "location": "Singapore; program in Sydney or Amsterdam",
    "statusTiming": "Open now | 8-week program",
    "responsibilities": "Trading fundamentals; live-data simulation; analyse historical data; develop and backtest an algorithmic trading strategy; exposure to trading desks.",
    "candidateRequirements": "Penultimate/pre-penultimate student; strong quantitative/logical reasoning; collaborative; interest in competitive activities; Python is a plus.",
    "priorFinanceRequired": "No explicit prior-finance requirement",
    "boundaryObservation": "Research project and backtesting sit inside the trading internship, so trading is not purely real-time execution.",
    "officialSourceUrl": "https://www.optiver.com/join-us/jobs/institutional-sales-and-trading/singapore/quantitative-trading-internship-singapore-2027/?gh_jid=8642260002"
  },
  {
    "company": "Optiver",
    "officialRoleTitle": "Expressions of Interest – Graduate Quantitative Researcher 2027",
    "level": "Graduate",
    "location": "Sydney",
    "statusTiming": "Expression of Interest / Talent Community | formal Graduate applications closed",
    "responsibilities": "Build statistical/ML models for trading strategies; analyse high-frequency data and market microstructure; build stochastic pricing models; combine quantitative analysis with high-performance implementation.",
    "candidateRequirements": "Final-year student/recent graduate; quantitative/technical degree; programming experience; Australian/NZ citizenship, PR or evidence of full working rights.",
    "priorFinanceRequired": "No explicit prior-finance requirement",
    "boundaryObservation": "Research spans signal discovery, pricing, execution-performance research and implementation, so there is internal diversity even within 'Research'.",
    "officialSourceUrl": "https://www.optiver.com/join-us/jobs/quantitative-research-and-machine-learning/sydney/expressions-of-interest-graduate-quantitative-researcher-2027/"
  },
  {
    "company": "Optiver",
    "officialRoleTitle": "Software Engineer Internship",
    "level": "Internship",
    "location": "Sydney + other offices",
    "statusTiming": "Program information only | Sydney listed as an internship location; check office-specific vacancy",
    "responsibilities": "Technical bootcamp; design, develop and deploy systems affecting trading/research stacks; write production-level high-performance code; solve scaling/efficiency problems; collaborate with engineers, traders and researchers.",
    "candidateRequirements": "CS/software engineering or related STEM; strong programming fundamentals; evidence of technical curiosity and problem solving.",
    "priorFinanceRequired": "No stated finance requirement",
    "boundaryObservation": "The role is engineering-led but embedded directly in trading and research workflows.",
    "officialSourceUrl": "https://www.optiver.com/join-us/students/internships/technology/"
  },
  {
    "company": "IMC Trading",
    "officialRoleTitle": "Trading Internship – APAC",
    "level": "Internship",
    "location": "Sydney / APAC",
    "statusTiming": "Status unknown — verify before applying | page says “Applications Now Open” but shows 0 of 0 / No Jobs Found; duration wording also conflicts (9 vs 10 weeks)",
    "responsibilities": "Financial-markets training; game theory, options, volatility and arbitrage; Python; quant research and ML; generate and test signals; build and refine an automated trading strategy.",
    "candidateRequirements": "APAC overview requirements for Trading/QR: High Distinction (or equivalent), Australian working rights, penultimate year preferred. Academic focus includes maths/statistics/engineering/computer science/physics or related STEM; the Trading page also lists science, actuarial, finance and economics backgrounds.",
    "priorFinanceRequired": "No prior trading/financial-markets experience required",
    "boundaryObservation": "The trading internship itself contains quant research, ML and automated strategy development.",
    "officialSourceUrl": "https://www.imc.com/ap/careers/students-graduates/internships/trading-internship"
  },
  {
    "company": "IMC Trading",
    "officialRoleTitle": "Quantitative Research Internship – APAC",
    "level": "Internship",
    "location": "Sydney / APAC",
    "statusTiming": "Closed / No matching vacancies | program page active, but current page shows 0 of 0 / No Jobs Found | 10-week program",
    "responsibilities": "Trading concepts; options theory; statistical modelling; ML; Python/data science; explore market datasets; identify patterns; develop models and signals; automated strategy simulation.",
    "candidateRequirements": "APAC overview requirements for Trading/QR: High Distinction (or equivalent), Australian working rights, penultimate year preferred. Role page: Bachelor's/Master's in a highly quantitative field; programming proficiency required, preferably Python (or C++/Java/Matlab/R).",
    "priorFinanceRequired": "No prior trading/financial-markets experience required",
    "boundaryObservation": "QR differs in emphasis, but shares strategy, signals, market data and automated trading with the trading stream.",
    "officialSourceUrl": "https://www.imc.com/ap/careers/students-graduates/internships/quantitative-research-internships"
  },
  {
    "company": "IMC Trading",
    "officialRoleTitle": "Engineering Internship – APAC",
    "level": "Internship",
    "location": "Sydney / APAC",
    "statusTiming": "Closed / No matching vacancies | program page active, but current page shows 0 of 0 / No Jobs Found | 10-week program",
    "responsibilities": "C++/Java/Python; technical training; individual research-based project to improve system/tool performance; production-impact focus; trading simulation also included.",
    "candidateRequirements": "APAC overview requirements for Technology: High Distinction (or equivalent), Australian working rights, penultimate year of study. Role page: relevant undergraduate field, ideally computer science/software engineering/programming; coding assessment in C++, Java or Python.",
    "priorFinanceRequired": "No prior trading/financial-markets experience required",
    "boundaryObservation": "Engineering is technically distinct, yet interns learn trading and build systems/tools used by trading operations.",
    "officialSourceUrl": "https://www.imc.com/ap/careers/students-graduates/internships/technology-internship"
  },
  {
    "company": "Akuna Capital",
    "officialRoleTitle": "Junior Trader",
    "level": "Early career / full-time",
    "location": "Chicago",
    "statusTiming": "Open now | next available start date stated as August 2027",
    "responsibilities": "Learn options market making; use proprietary technology; implement trading strategies and ideas; make fast market decisions; possible desks include Options MM, Delta One, Vol Arb, Crypto and Quantitative Strategy Group.",
    "candidateRequirements": "BS/MS/PhD in quantitative/technical/economic field by employment; strong math and numerical analysis; strong communication; fast reaction; programming preferred; major GPA 3.5+; US work authorization.",
    "priorFinanceRequired": "No prior trading experience stated as a requirement",
    "boundaryObservation": "Trading emphasizes real-time decisions, but one destination team is Quantitative Strategy Group and coding/problem solving appear in candidate requirements.",
    "officialSourceUrl": "https://akunacapital.com/careers/job/7773141/junior-trader/?gh_jid=7773141"
  },
  {
    "company": "Akuna Capital",
    "officialRoleTitle": "Quantitative Research Intern, Summer 2027",
    "level": "Internship",
    "location": "Chicago",
    "statusTiming": "Open now | 10-week Akunacademy",
    "responsibilities": "Develop strategies with statistical/ML algorithms; portfolio optimisation; quantitative models of market behaviour; explore new research topics.",
    "candidateRequirements": "Bachelor's/Master's/PhD in quantitative technical field; statistics/ML expertise; mathematical modelling; intermediate Python; graduate by Aug 2028; GPA 3.5+; US work authorization.",
    "priorFinanceRequired": "No",
    "boundaryObservation": "Research is strategy-centric and explicitly blends mathematical modelling, programming and market behaviour.",
    "officialSourceUrl": "https://akunacapital.com/careers/job/8036614/talent-community/"
  },
  {
    "company": "Akuna Capital",
    "officialRoleTitle": "Software Engineer Intern – Python, Summer 2027",
    "level": "Internship",
    "location": "Chicago",
    "statusTiming": "Open now | 10-week Akunacademy",
    "responsibilities": "Work in Post Trade Technology or Data Engineering; build solutions with engineers and traders; process/analyse large volumes of trading and market data; own and present a project.",
    "candidateRequirements": "Technical degree; graduate by Aug 2028; GPA 3.5+; US work authorization; strong OOP Python; distributed-systems exposure; analytical/problem-solving skills.",
    "priorFinanceRequired": "No",
    "boundaryObservation": "Engineering remains tightly coupled to trading workflows and market data; the firm stresses integration between software and trading groups.",
    "officialSourceUrl": "https://akunacapital.com/careers/job/8018853/?gh_jid=8018853"
  },
  {
    "company": "Citadel Securities",
    "officialRoleTitle": "Quantitative Trading – Intern (Australia)",
    "level": "Internship",
    "location": "Sydney",
    "statusTiming": "Open now | 11-week program",
    "responsibilities": "Make real-time risk decisions; use predictive analytics and advanced technology; monitor risk and market signals; execute trading strategies; apply advanced statistical techniques to trading.",
    "candidateRequirements": "Bachelor's/Master's/PhD in applied math, engineering, statistical modelling, calculus, computer science, physics or related fields; systematic quantitative thinking; interest in technology/quant trading problems; programming/statistical software strongly preferred.",
    "priorFinanceRequired": "No prior finance experience stated as a formal requirement",
    "boundaryObservation": "Trading is explicitly statistical and model-driven, overlapping strongly with research-style skills.",
    "officialSourceUrl": "https://www.citadelsecurities.com/careers/details/quantitative-trading-intern-australia/"
  },
  {
    "company": "Citadel Securities",
    "officialRoleTitle": "Quantitative Research Analyst Intern – BS/MS (Australia)",
    "level": "Internship",
    "location": "Sydney",
    "statusTiming": "Open now",
    "responsibilities": "Develop/test automated quant trading strategies; build valuation and mathematical models; backtest and implement models/signals in live trading; use unconventional data; conduct research and statistical analysis.",
    "candidateRequirements": "Bachelor's/Master's in math, statistics, physics, CS or another highly quantitative field; strong probability/statistics; data-driven research experience; Python/R/C++; independent research; communication.",
    "priorFinanceRequired": "No finance requirement stated",
    "boundaryObservation": "Research responsibilities extend all the way from modelling to live implementation, making the boundary with trading and engineering operational rather than clean.",
    "officialSourceUrl": "https://www.citadelsecurities.com/careers/details/quantitative-research-analyst-intern-bs-ms-australia/"
  },
  {
    "company": "Citadel Securities",
    "officialRoleTitle": "Software Engineer – Intern (Australia)",
    "level": "Internship",
    "location": "Sydney",
    "statusTiming": "Open now | 11-week program",
    "responsibilities": "Build high-performing and resilient technology; create systems/platforms; develop high-performance large-data research platforms; create tools that bring trading strategies to life.",
    "candidateRequirements": "Bachelor's/Master's/PhD in CS/computer engineering or related field; exceptional programming/design skills; analytical skills; familiarity with probability/statistics; collaborative communication.",
    "priorFinanceRequired": "No finance requirement stated",
    "boundaryObservation": "Engineering is clearly technical, but the official objectives directly connect software to research platforms and production trading strategies.",
    "officialSourceUrl": "https://www.citadelsecurities.com/careers/details/software-engineer-intern-australia/"
  },
  {
    "company": "Susquehanna (SIG)",
    "officialRoleTitle": "Quantitative Systematic Trading Internship – PhD (Sydney)",
    "level": "Internship",
    "location": "Sydney",
    "statusTiming": "Open now | flexible start | 10-week program",
    "responsibilities": "Apply probability, statistics and mathematical creativity to trading projects; transform quantitative modelling into trading opportunities/strategies; training in options theory and modelling; collaborate with researchers, traders and technologists.",
    "candidateRequirements": "Penultimate-year PhD in quantitative field; analytical problem solving; logical reasoning; communication; code to process/analyse large datasets, especially Python; C++/low-level language a plus; interest in strategic games/competition.",
    "priorFinanceRequired": "No prior finance background required; firm provides training",
    "boundaryObservation": "SIG explicitly describes the broader QST role as a true hybrid of trading, technology and quantitative research; Sydney applicants are automatically considered for QR too.",
    "officialSourceUrl": "https://careers.sig.com/quantitative-trading-internships-co-ops/jobs/10435?lang=en-us"
  },
  {
    "company": "Susquehanna (SIG)",
    "officialRoleTitle": "Quantitative Research Internship – PhD (Sydney)",
    "level": "Internship",
    "location": "Sydney",
    "statusTiming": "Open now | flexible start | 10-week program",
    "responsibilities": "Apply probability, statistics and mathematical creativity to trading projects; collaborate across research, trading and technology to convert quantitative modelling into trading opportunities and strategies.",
    "candidateRequirements": "Penultimate-year PhD in quantitative field; exceptional mathematical problem solving; communication; strong practical computing; in-depth research-project experience; visa sponsorship available.",
    "priorFinanceRequired": "No prior finance background required; training provided",
    "boundaryObservation": "The QR page automatically cross-considers candidates for QST, which is direct evidence that the roles overlap enough to share an applicant pool.",
    "officialSourceUrl": "https://careers.sig.com/jobs/10429?lang=en-us"
  },
  {
    "company": "Susquehanna (SIG)",
    "officialRoleTitle": "Trading System Engineering Internship – Summer 2027",
    "level": "Internship",
    "location": "Philadelphia-area (reviewed role); related roles also in Hong Kong",
    "statusTiming": "Open now | 10-week program",
    "responsibilities": "Solve problems at the intersection of trading, data and technology; develop low-latency C++ trading systems; work on projects for trading-strategy development teams alongside senior developers.",
    "candidateRequirements": "Bachelor's/Master's in CS, computer engineering, mathematics or related STEM; strong C++/C/Rust/C#/Java and some Python; logical reasoning; expected full-time availability after graduation; visa sponsorship available.",
    "priorFinanceRequired": "No prior finance requirement stated; market education is part of internship",
    "boundaryObservation": "The engineering track is explicitly built around trading-strategy development, showing technology is not isolated from the quant/trading workflow.",
    "officialSourceUrl": "https://careers.sig.com/global-susquehanna/jobs/10837?lang=en-us"
  },
  {
    "company": "DRW",
    "officialRoleTitle": "Quantitative Trading Analyst Intern",
    "level": "Internship",
    "location": "Chicago",
    "statusTiming": "Open now | Summer 2027 | 10-week program",
    "responsibilities": "Combine technology, research and risk management; improve trading strategies; conduct market-research projects from macro data to ML on tick data; position tracking, risk calculations and theoretical-value analysis.",
    "candidateRequirements": "Bachelor's/Master's/PhD in quantitative/technical field; advanced quantitative/problem-solving skills; Python; communication; interest in markets; graduation between Dec 2027 and Jun 2028.",
    "priorFinanceRequired": "Finance experience not listed as a formal requirement",
    "boundaryObservation": "DRW says the trading internship combines technology, research and risk management, making cross-role work explicit.",
    "officialSourceUrl": "https://www.drw.com/work-at-drw/listings/quantitative-trading-analyst-intern-3375090"
  },
  {
    "company": "DRW",
    "officialRoleTitle": "Quantitative Research Intern",
    "level": "Internship",
    "location": "Chicago / New York City",
    "statusTiming": "Open now | Summer 2027",
    "responsibilities": "Use statistical/scientific algorithms, ML and derivatives pricing; conduct market-data analysis; formulate mathematical models; backtest/validate models in custom infrastructure; identify trading opportunities.",
    "candidateRequirements": "Bachelor's/Master's/PhD in technical field; Python ML stack; large datasets; statistics/probability; strong analytical skills; communication; some NLP/HPC exposure is a plus.",
    "priorFinanceRequired": "No finance experience listed as a requirement",
    "boundaryObservation": "QR is technically research-heavy but projects are advised by traders and designed for direct trading applications.",
    "officialSourceUrl": "https://www.drw.com/work-at-drw/listings/quantitative-research-intern-3413670"
  },
  {
    "company": "DRW",
    "officialRoleTitle": "Software Developer Intern",
    "level": "Internship",
    "location": "Chicago",
    "statusTiming": "Open now | Summer 2027 | 10-week program",
    "responsibilities": "Build trading/risk applications, market-data decoders/normalizers and other proprietary systems; conduct data-driven statistical research; collaborate with developers, quantitative traders and researchers.",
    "candidateRequirements": "Bachelor's/Master's/PhD in CS/engineering/physics/math/ML or related field; OOP/data structures/algorithms; strong development skills; exposure to real-time, multithreaded or computationally intensive systems.",
    "priorFinanceRequired": "No finance requirement stated",
    "boundaryObservation": "Even general software interns can do statistical research and collaborate directly with quant traders/researchers.",
    "officialSourceUrl": "https://www.drw.com/work-at-drw/listings/software-developer-intern-3467328"
  },
  {
    "company": "Two Sigma",
    "officialRoleTitle": "Quantitative Researcher – Internship [2027 Summer]",
    "level": "Internship",
    "location": "New York",
    "statusTiming": "Open now | 2027 internship applications open",
    "responsibilities": "Conduct research on financial data, forecasting and statistical models; apply scientific thinking, ML and time-series techniques; work on real-world alpha-modelling problems and a summer research project.",
    "candidateRequirements": "Current internship page emphasizes research ability and scientific problem solving; broader QR career materials emphasize quantitative/technical backgrounds, programming and research with real-world data.",
    "priorFinanceRequired": "No prior finance background stated as required",
    "boundaryObservation": "Two Sigma frames this work as Quant Research/Data Science rather than separating out a dedicated student 'Trader' track.",
    "officialSourceUrl": "https://www.twosigma.com/careers/internships/"
  },
  {
    "company": "Two Sigma",
    "officialRoleTitle": "Software Engineering Internship",
    "level": "Internship / program information",
    "location": "New York",
    "statusTiming": "Program information only | current 2027 internship list did not show a SWE opening",
    "responsibilities": "Build software, systems and infrastructure for large datasets and simulations; support research, cloud/data systems and trading infrastructure; interns work on a dedicated project with mentorship.",
    "candidateRequirements": "Technical/quantitative degree coursework; programming skills; large-scale systems/analytical ability. Two Sigma states financial experience is not required in its SWE internship JD materials.",
    "priorFinanceRequired": "No",
    "boundaryObservation": "Engineering is a core student pathway, while a separate Quant Trader internship is absent from the current student taxonomy—evidence that firm role structures differ materially.",
    "officialSourceUrl": "https://www.twosigma.com/careers/internships/"
  }
];

const companyMeta: Record<string,{companyType:CompanyType;companyScaleLabel:string;statusCheckedDate:string}> = {
  "Jane Street": { companyType:"Proprietary/diversified trading", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-21" },
  "Optiver": { companyType:"Global market maker", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-21" },
  "IMC Trading": { companyType:"Global market maker", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-21" },
  "Akuna Capital": { companyType:"Global market maker", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-21" },
  "Citadel Securities": { companyType:"Global market maker", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-22" },
  "Susquehanna (SIG)": { companyType:"Proprietary/diversified trading", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-22" },
  "DRW": { companyType:"Proprietary/diversified trading", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-22" },
  "Two Sigma": { companyType:"Quantitative investment", companyScaleLabel:"Global firm", statusCheckedDate:"2026-08-22" },
};

const slug = (value:string) => value.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"");
const familyFor = (title:string):RoleFamily => /software|engineering|developer/i.test(title) ? "Software Engineering" : /research/i.test(title) ? "Quantitative Research" : "Quantitative Trading";
const statusFor = (value:string):ApplicationStatus => value.startsWith("Open now") ? "Open now" : value.startsWith("Expression of Interest") ? "EOI / Talent Community" : value.startsWith("Program information") ? "Program information only" : value.startsWith("Closed") ? "Closed / no matching jobs" : "Unknown — verify";
const statements = (value:string, pattern:RegExp) => value.split(/(?<=[.;])/).map(x=>x.trim()).filter(x=>pattern.test(x)).join(" ") || NS;
const evidenceFor = (role:RawRole):"Official JD"|"Official program page" => /program information/i.test(role.level + role.statusTiming) || (role.company === "Optiver" && role.officialRoleTitle === "Software Engineer Internship") ? "Official program page" : "Official JD";

export const roles: Role[] = rawRoles.map((raw,index) => {
  const meta = companyMeta[raw.company];
  const applicationStatus = statusFor(raw.statusTiming);
  const normalizedRoleFamily = familyFor(raw.officialRoleTitle);
  const evidenceType = evidenceFor(raw);
  const workingRights = statements(raw.candidateRequirements,/work(ing)? rights|work authorization|citizenship|permanent residenc|\bPR\b|visa sponsorship/i);
  const educationRequirements = statements(raw.candidateRequirements,/bachelor|master|phd|degree|student|undergraduate|graduate|quantitative field|STEM/i);
  const graduationWindow = statements(raw.candidateRequirements,/graduat|penultimate|final-year|full-time availability/i);
  const academicRequirement = statements(raw.candidateRequirements,/High Distinction|GPA 3\.5\+/i);
  const statusCheckedDate = meta?.statusCheckedDate ?? "Not verified";
  const accessedDate = statusCheckedDate === "2026-08-21" ? "21 Aug 2026" : statusCheckedDate === "2026-08-22" ? "22 Aug 2026" : "Not verified";
  const statusCaveat = raw.company === "Optiver" && /2027/.test(raw.officialRoleTitle)
    ? `${raw.statusTiming}. Source conflict preserved: the reviewed title says 2027 while the page body still refers to the 2026 campaign.`
    : raw.statusTiming;
  return {
    id: `role-${index+1}-${slug(raw.company)}-${slug(raw.officialRoleTitle).slice(0,42)}`,
    company: raw.company,
    companyType: meta?.companyType ?? "Other",
    companyScaleLabel: meta?.companyScaleLabel ?? "Not verified",
    officialRoleTitle: raw.officialRoleTitle,
    normalizedRoleFamily,
    level: raw.level,
    location: raw.location,
    workingRights,
    educationRequirements,
    responsibilities: raw.responsibilities,
    requiredSkills: raw.candidateRequirements,
    priorFinanceRequired: raw.priorFinanceRequired || NS,
    applicationStatus,
    statusCheckedDate,
    officialSourceUrl: raw.officialSourceUrl,
    evidenceType,
    confidence: applicationStatus === "Unknown — verify" ? "Official source contains a status conflict" : evidenceType === "Official program page" ? "Program verified; current vacancy not verified" : "Verified official company source",
    boundaryObservation: raw.boundaryObservation,
    statusCaveat,
    officialTitle: raw.officialRoleTitle,
    normalisedRoleFamily: normalizedRoleFamily,
    programYear: raw.statusTiming.match(/20\d{2}/)?.[0] ?? NS,
    preferredSkills: NS,
    degreeRequirements: educationRequirements,
    graduationWindow,
    academicRequirement,
    workRights: workingRights,
    financeBackgroundWording: raw.priorFinanceRequired || NS,
    sourceUrl: raw.officialSourceUrl,
    accessedDate,
    sourceType: "Official JD / company source",
    limitations: applicationStatus === "Open now" ? "Official-source snapshot; verify current details before applying." : "Current availability must be verified before applying.",
    evidenceKind: evidenceType,
  };
});

export const companies = Array.from(new Set(roles.map(role=>role.company)));
export const dataStats = { companyCount: companies.length, roleCount: roles.length };

export const statusDefinitions: Record<ApplicationStatus,string> = {
  "Open now":"A specific reviewed role page provided an active application route when checked.",
  "EOI / Talent Community":"Interest can be registered, but this is not a current formal application.",
  "Program information only":"The program page exists; a current vacancy is not confirmed.",
  "Closed / no matching jobs":"The reviewed page indicated no current matching vacancy.",
  "Unknown — verify":"Official signals conflict or do not establish current availability.",
};

export const futureEvidence = { survey: [] as unknown[], interview: [] as unknown[] };
