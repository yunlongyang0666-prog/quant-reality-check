"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { roles, type Role, type RoleFamily } from "./data";
import {
  careerStageOptions, dimensions, expectationOptions, informationGapOptions,
  preparationOptions, resultForAnswers, scenarios, targetRoleOptions,
} from "./workstyle";

type AnswerKey = "A"|"B"|"C";
type Phase = "intro"|"questions"|"result";
type ResultConfig = ReturnType<typeof resultForAnswers>["config"];
type ExplorerState = {
  careerStage:string; target:string; informationGaps:string[]; scenarioAnswers:AnswerKey[];
  expectations:string[]; preparation:string[];
};

const STORAGE_KEY = "qrc-integrated-reality-check-v2";
const emptyState:ExplorerState = {careerStage:"",target:"",informationGaps:[],scenarioAnswers:[],expectations:[],preparation:[]};

function resultUrl(state:ExplorerState){
  const url=new URL(window.location.href);
  url.searchParams.set("workstyle",state.scenarioAnswers.join(""));
  url.searchParams.set("target",state.target||"Unsure");
  return url.toString();
}

function roleFamilyFor(target:string,config:ResultConfig):RoleFamily{
  if(target==="Quantitative Trading"||target==="Quantitative Research")return target;
  if(target==="Software / Quantitative Engineering")return "Software Engineering";
  return config.directions[0] as RoleFamily;
}

function evidenceRoles(config:ResultConfig,target:string){
  const family=roleFamilyFor(target,config);
  const sameFamily=roles.filter(role=>role.normalisedRoleFamily===family);
  const preferred=config.evidenceQueries.map((query:{company:string;title:string})=>roles.find(role=>role.company===query.company&&role.officialRoleTitle.includes(query.title))).filter(Boolean) as Role[];
  const ordered=[...sameFamily,...preferred];
  return [...new Map(ordered.map(role=>[role.id,role])).values()].slice(0,5);
}

const taskTaxonomy = [
  {label:"Analysing datasets",pattern:/data|statistical analysis|historical/i},
  {label:"Developing and validating models",pattern:/model|signal|backtest|hypothesis|research/i},
  {label:"Making real-time risk decisions",pattern:/real-time|risk decision|fast market decision|execute trading/i},
  {label:"Monitoring markets",pattern:/monitor|market signal|market data|market making/i},
  {label:"Writing production software",pattern:/production|software|develop systems|build systems|code/i},
  {label:"Optimising latency and system performance",pattern:/latency|performance|high-performance|scaling|efficiency/i},
  {label:"Building data pipelines",pattern:/pipeline|data engineering|market-data decoder|infrastructure/i},
  {label:"Pricing, liquidity or execution work",pattern:/pric|liquidity|execution|market mak|options|arbitrage/i},
  {label:"Communicating research or trading decisions",pattern:/communicat|collaborat|present/i},
];

const fingerprintTaxonomy = [
  {label:"Research and model validation",pattern:/research|model|signal|backtest|statistical|machine learning|\bML\b/i},
  {label:"Real-time decision making",pattern:/real-time|decision|trading intuition|mock trading|simulation|execute strateg/i},
  {label:"Software and production systems",pattern:/production|software|code|developer|high-performance implementation|trading system/i},
  {label:"Data and infrastructure",pattern:/dataset|historical data|pipeline|infrastructure|market data|data engineering/i},
  {label:"Risk and liquidity",pattern:/risk|liquidity|market making|volatility|options/i},
  {label:"Pricing and execution",pattern:/pric|execution|arbitrage|trade execution|automated trading/i},
  {label:"Communication and collaboration",pattern:/communicat|collaborat|team|present/i},
];

const preparationTaxonomy = [
  {label:"Probability and mathematics",pattern:/probability|mathemat|quantitative|stochastic|game theory/i},
  {label:"Statistics and machine learning",pattern:/statistical|statistics|machine learning|\bML\b|model/i},
  {label:"Python and data analysis",pattern:/Python|data analys|dataset/i},
  {label:"Algorithms and data structures",pattern:/algorithm|data structure|problem solving/i},
  {label:"C++ and systems programming",pattern:/C\+\+|systems programming|concurrency|performance|low-latency|high-performance/i},
  {label:"Market knowledge",pattern:/market|trading|options|liquidity|pricing|execution/i},
  {label:"Mental maths or trading games",pattern:/mental math|trading game|competitive activit/i},
  {label:"Interview questions",pattern:/interview|assessment/i},
  {label:"Networking and company research",pattern:/network|company research/i},
];

function advertisedTasks(selected:Role[]){
  const source=selected.map(role=>`${role.responsibilities} ${role.requiredSkills}`).join(" ");
  return taskTaxonomy.filter(task=>task.pattern.test(source)).map(task=>task.label);
}

function distinctFirmExamples(selected:Role[]){
  const seen=new Set<string>();
  return selected.filter(role=>!seen.has(role.company)&&seen.add(role.company)).slice(0,3);
}

function fingerprintFor(role:Role){
  const source=`${role.responsibilities} ${role.requiredSkills}`;
  return fingerprintTaxonomy.filter(item=>item.pattern.test(source)).map(item=>item.label);
}

function preparationAnalysis(state:ExplorerState,selected:Role[]){
  const source=selected.map(role=>`${role.responsibilities} ${role.requiredSkills}`).join(" ");
  const relevant=state.preparation.filter(item=>preparationTaxonomy.find(entry=>entry.label===item)?.pattern.test(source));
  const lower=state.preparation.filter(item=>item!=="I have not started preparing"&&!relevant.includes(item));
  const possible=preparationTaxonomy.filter(item=>item.pattern.test(source)&&!state.preparation.includes(item.label)).map(item=>item.label).slice(0,3);
  return {relevant,lower,possible};
}

function nextActions(state:ExplorerState,config:ResultConfig,selected:Role[],actual:string[]){
  const first=selected[0]; const second=selected[1]; const gap=state.informationGaps[0]||"What I should prepare first";
  const comparisonFocus=gap.includes("Eligibility")?"degree, graduation timing and working-right wording":gap.includes("Interview")||gap.includes("Recruitment")?"application status and any stated recruitment details":gap.includes("programming")||gap.includes("Mathematics")?"mathematics and programming wording":"one shared task and one company-specific difference";
  const gapAction=`Compare the official ${first.company} — ${first.officialRoleTitle} and ${second.company} — ${second.officialRoleTitle} descriptions, focusing on ${comparisonFocus}.`;
  const stageAction = state.careerStage.includes("recently heard")
    ? `Read one ${config.directions[0]} JD and one adjacent role JD before choosing a title.`
    : state.careerStage.includes("comparing")
      ? `Use Compare to inspect two firms in the same role family without reducing them to a score.`
      : state.careerStage.includes("not started")
        ? `Choose one 45-minute task sample from the advertised work before building a preparation plan.`
        : state.careerStage.includes("preparing to apply")
          ? `Re-check one live status, deadline signal and explicit eligibility constraint before applying.`
          : state.careerStage.includes("applied or interviewed")
            ? `Re-read the exact JD used for your application and prepare one example for a stated responsibility.`
            : `Compare your lived task mix with one official JD and note one title assumption that changed.`;
  const uncovered=actual.find(task=>!state.expectations.includes(task));
  const experimentAction=state.preparation.includes("I have not started preparing")
    ? config.actions[1]
    : uncovered
      ? `Try a small task related to “${uncovered}”, then record what felt interesting and what remains unclear; this is exploration, not an ability test.`
      : config.actions[2];
  return [gapAction,experimentAction,stageAction];
}

function ResultArt({kind}:{kind:string}){
  if(kind==="signal")return <svg className="result-art art-signal" viewBox="0 0 420 280" role="img" aria-label="Signal Explorer: irregular data points, waveform and magnifier"><defs><pattern id="dots-signal" width="22" height="22" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1.5" fill="#7C6CF2" opacity=".3"/></pattern></defs><path className="art-bg" d="M15 42 314 14l91 92-38 154-303 7L8 171Z"/><path fill="url(#dots-signal)" d="M15 42 314 14l91 92-38 154-303 7L8 171Z"/><path className="stroke-a" d="M32 183c45 0 41-104 90-104s54 132 105 132 49-166 97-166"/><g className="stroke-b"><circle cx="314" cy="96" r="46"/><path d="m348 130 42 42"/></g>{[[63,183],[122,79],[227,211],[324,45]].map(([x,y])=><circle key={`${x}`} cx={x} cy={y} r="7" className="dot"/>)}</svg>;
  if(kind==="market")return <svg className="result-art art-market" viewBox="0 0 420 280" role="img" aria-label="Market Navigator: vertical compass, arrows and radar pulses"><rect className="art-bg" x="70" y="8" width="280" height="264" rx="110"/><g className="pulse"><ellipse cx="210" cy="142" rx="145" ry="62"/><ellipse cx="210" cy="142" rx="102" ry="42"/><ellipse cx="210" cy="142" rx="58" ry="24"/></g><path className="needle" d="m210 22 34 119-34 117-34-117Z"/><path className="arrow" d="m210 24 24 92-24 25-24-25Z"/><path className="ticks" d="M36 142h56m236 0h56M210 5v35m0 204v31"/></svg>;
  if(kind==="systems")return <svg className="result-art art-systems" viewBox="0 0 420 280" role="img" aria-label="Systems Builder: modules, nodes, circuits and data pipeline"><defs><pattern id="grid-systems" width="24" height="24" patternUnits="userSpaceOnUse"><path d="M24 0H0v24" fill="none" stroke="#31C7B5" opacity=".15"/></pattern></defs><rect className="art-bg" x="5" y="5" width="410" height="270" rx="12"/><rect x="5" y="5" width="410" height="270" rx="12" fill="url(#grid-systems)"/><g className="modules"><rect x="38" y="42" width="96" height="64" rx="8"/><rect x="162" y="108" width="96" height="64" rx="8"/><rect x="286" y="174" width="96" height="64" rx="8"/></g><path className="circuit" d="M134 74h48v34m76 32h48v34M86 106v98h76m48-96V52h76m-76 120v62"/><g className="nodes"><circle cx="86" cy="204" r="8"/><circle cx="286" cy="52" r="8"/><circle cx="210" cy="234" r="8"/></g></svg>;
  if(kind==="synth")return <svg className="result-art art-synth" viewBox="0 0 420 280" role="img" aria-label="Strategy Synthesizer: two contrasting paths crossing"><path className="art-bg" d="M16 21h388v238H16z"/><path className="path-one" d="M24 224C110 224 117 48 210 48s94 176 186 176"/><path className="path-two" d="M24 54c86 0 98 170 186 170S304 54 396 54"/><path className="cross" d="m182 112 56 56m0-56-56 56"/><circle cx="210" cy="140" r="23" className="hub"/></svg>;
  if(kind==="bridge")return <svg className="result-art art-bridge" viewBox="0 0 420 280" role="img" aria-label="Model-to-Market Builder: model flowing over a bridge into a system"><path className="art-bg" d="M8 20h404v240H8z"/><g className="model"><circle cx="76" cy="137" r="52"/><path d="M45 146h20l13-30 18 46 14-25h19"/></g><path className="flow" d="M128 137h46c20 0 20-52 42-52s24 104 48 104h28"/><path className="bridge-deck" d="M145 190h150M164 190v36m38-36v36m38-36v36m38-36v36"/><g className="system"><rect x="292" y="88" width="98" height="98" rx="12"/><path d="M310 112h62m-62 25h44m-44 25h55"/></g></svg>;
  if(kind==="execution")return <svg className="result-art art-execution" viewBox="0 0 420 280" role="img" aria-label="Execution Architect: diagonal lightning and low-latency circuit"><path className="art-bg" d="M3 214 310 4l107 61-306 211Z"/><path className="speed-lines" d="M22 222 190 106M72 260 240 144M180 270 362 144"/><path className="bolt" d="m242 18-119 142h87l-35 105 130-157h-91Z"/><path className="circuit" d="M42 66h86v42m165 80h85m-43 0v-42M44 238h80v-43"/><g className="nodes"><circle cx="128" cy="108" r="7"/><circle cx="335" cy="146" r="7"/><circle cx="124" cy="195" r="7"/></g></svg>;
  return <svg className="result-art art-prism" viewBox="0 0 420 280" role="img" aria-label="Open Explorer: prism and three radiating paths"><defs><radialGradient id="prism-glow"><stop stopColor="#8A87A8" stopOpacity=".45"/><stop offset="1" stopColor="#171B27" stopOpacity="0"/></radialGradient></defs><circle cx="210" cy="140" r="136" fill="url(#prism-glow)"/><path className="prism" d="m210 38-84 168h168Z"/><path className="incoming" d="M14 140h140"/><path className="ray ray-a" d="m266 140 127-83"/><path className="ray ray-b" d="m266 140 142 5"/><path className="ray ray-c" d="m266 140 119 91"/><g className="orbit"><circle cx="210" cy="140" r="112"/><circle cx="210" cy="140" r="76"/></g></svg>;
}

function wrapText(ctx:CanvasRenderingContext2D,text:string,x:number,y:number,maxWidth:number,lineHeight:number,maxLines=6){
  const words=text.split(" ");let line="";let lines=0;
  for(const word of words){const test=`${line}${word} `;if(ctx.measureText(test).width>maxWidth&&line){ctx.fillText(line.trim(),x,y);line=`${word} `;y+=lineHeight;lines++;if(lines>=maxLines-1)break}else line=test}
  if(line&&lines<maxLines)ctx.fillText(line.trim(),x,y);return y;
}

function drawCanvasIdentity(ctx:CanvasRenderingContext2D,config:ResultConfig){
  const kind=config.illustration;ctx.save();ctx.translate(540,380);ctx.lineWidth=13;ctx.lineCap="round";ctx.lineJoin="round";ctx.strokeStyle=config.accent;ctx.fillStyle=config.accent2;
  if(kind==="signal"){ctx.beginPath();ctx.moveTo(-360,65);ctx.bezierCurveTo(-210,65,-205,-170,-55,-70);ctx.bezierCurveTo(70,15,105,-190,255,-120);ctx.stroke();ctx.beginPath();ctx.arc(235,-88,92,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(300,-23);ctx.lineTo(365,42);ctx.stroke();[[-310,65],[-55,-70],[70,15]].forEach(([x,y])=>{ctx.beginPath();ctx.arc(x,y,14,0,Math.PI*2);ctx.fill()})}
  else if(kind==="market"){ctx.strokeStyle=config.accent;[190,125,62].forEach(r=>{ctx.beginPath();ctx.ellipse(0,0,r,r*.42,0,0,Math.PI*2);ctx.stroke()});ctx.fillStyle=config.accent2;ctx.beginPath();ctx.moveTo(0,-240);ctx.lineTo(55,0);ctx.lineTo(0,215);ctx.lineTo(-55,0);ctx.closePath();ctx.fill()}
  else if(kind==="systems"){ctx.strokeStyle=config.accent;ctx.lineWidth=9;[-250,-55,140].forEach((x,i)=>ctx.strokeRect(x,(i-1)*72-58,145,116));ctx.beginPath();ctx.moveTo(-105,-72);ctx.lineTo(-35,-72);ctx.lineTo(-35,0);ctx.lineTo(-55,0);ctx.moveTo(90,0);ctx.lineTo(160,0);ctx.lineTo(160,72);ctx.stroke()}
  else if(kind==="synth"){ctx.strokeStyle=config.accent;ctx.beginPath();ctx.moveTo(-360,155);ctx.bezierCurveTo(-140,155,-120,-190,0,-70);ctx.bezierCurveTo(130,55,160,150,360,150);ctx.stroke();ctx.strokeStyle=config.accent2;ctx.beginPath();ctx.moveTo(-360,-145);ctx.bezierCurveTo(-130,-145,-115,170,0,105);ctx.bezierCurveTo(130,30,155,-145,360,-145);ctx.stroke()}
  else if(kind==="bridge"){ctx.strokeStyle=config.accent;ctx.beginPath();ctx.arc(-280,-25,86,0,Math.PI*2);ctx.stroke();ctx.strokeStyle=config.accent2;ctx.strokeRect(200,-105,170,160);ctx.beginPath();ctx.moveTo(-194,-25);ctx.bezierCurveTo(-55,-25,-55,-155,45,-90);ctx.bezierCurveTo(105,-52,100,-25,200,-25);ctx.stroke();ctx.beginPath();ctx.moveTo(-170,95);ctx.lineTo(200,95);ctx.stroke()}
  else if(kind==="execution"){ctx.strokeStyle=config.accent;ctx.beginPath();ctx.moveTo(45,-255);ctx.lineTo(-145,20);ctx.lineTo(-20,20);ctx.lineTo(-70,235);ctx.lineTo(155,-80);ctx.lineTo(25,-80);ctx.closePath();ctx.stroke();ctx.strokeStyle=config.accent2;ctx.beginPath();ctx.moveTo(-360,210);ctx.lineTo(300,-210);ctx.stroke()}
  else{ctx.strokeStyle=config.accent;ctx.beginPath();ctx.moveTo(0,-220);ctx.lineTo(-190,145);ctx.lineTo(190,145);ctx.closePath();ctx.stroke();[[340,-150],[370,20],[320,205]].forEach(([x,y],i)=>{ctx.strokeStyle=[config.accent,"#6CAEA6","#B39A72"][i];ctx.beginPath();ctx.moveTo(70,0);ctx.lineTo(x,y);ctx.stroke()})}
  ctx.restore();
}

async function shareCardBlob(config:ResultConfig,scores:{research:number;decision:number;systems:number},url:string){
  const canvas=document.createElement("canvas");canvas.width=1080;canvas.height=1350;const ctx=canvas.getContext("2d");if(!ctx)throw new Error("Canvas is unavailable");
  ctx.fillStyle="#08111F";ctx.fillRect(0,0,1080,1350);ctx.fillStyle=config.background;ctx.beginPath();ctx.roundRect(70,70,940,1210,42);ctx.fill();
  if(config.illustration==="market"){ctx.fillStyle=config.accent;ctx.fillRect(70,70,940,82)}else if(config.illustration==="systems"){for(let x=70;x<1010;x+=94){ctx.fillStyle=x%188===70?config.accent:config.accent2;ctx.fillRect(x,70,72,28)}}else if(config.illustration==="execution"){ctx.fillStyle=config.accent;ctx.beginPath();ctx.moveTo(70,70);ctx.lineTo(1010,70);ctx.lineTo(790,190);ctx.lineTo(70,190);ctx.closePath();ctx.fill()}else if(config.illustration==="bridge"){ctx.fillStyle=config.accent;ctx.fillRect(70,70,470,76);ctx.fillStyle=config.accent2;ctx.fillRect(540,70,470,76)}else{ctx.fillStyle=config.accent;ctx.fillRect(70,70,18,190)}
  drawCanvasIdentity(ctx,config);
  ctx.textAlign="left";ctx.fillStyle="#9EACC1";ctx.font="700 25px Arial";ctx.fillText("QUANT CAREER REALITY CHECK",120,145);
  ctx.fillStyle="#E8EEF7";ctx.font="700 68px Arial";ctx.fillText(config.en,120,650);ctx.fillStyle=config.accent;ctx.font="38px Arial";ctx.fillText(config.zh,120,704);
  ctx.font="30px Arial";ctx.fillStyle="#C8D2E1";wrapText(ctx,config.description,120,770,840,42,4);
  (["research","decision","systems"] as const).forEach((key,index)=>{const y=925+index*68;ctx.fillStyle="#263754";ctx.beginPath();ctx.roundRect(120,y,660,22,11);ctx.fill();ctx.fillStyle=dimensions[key].color;ctx.beginPath();ctx.roundRect(120,y,Math.max(22,660*scores[key]/12),22,11);ctx.fill();ctx.fillStyle="#E8EEF7";ctx.font="24px Arial";ctx.fillText(dimensions[key].label,810,y+20)});
  ctx.fillStyle="#F6C667";ctx.font="700 24px Arial";ctx.fillText("CURRENT WORK-PREFERENCE SNAPSHOT",120,1150);ctx.fillStyle="#C8D2E1";ctx.font="24px Arial";wrapText(ctx,"Worth exploring first — evidence to investigate, not a career verdict.",120,1190,840,32,2);
  ctx.fillStyle="#9EACC1";ctx.font="22px Arial";ctx.fillText("Quant Reality Check",120,1250);ctx.textAlign="right";ctx.fillText(new URL(url).host||"Local prototype",960,1250);ctx.textAlign="center";ctx.fillStyle="#62D394";ctx.font="700 24px Arial";ctx.fillText("Explore, don’t conclude.",540,1315);
  return await new Promise<Blob>((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(new Error("PNG generation failed")),"image/png"));
}

function MultiChoice({options,selected,onChange,max}:{options:string[];selected:string[];onChange:(value:string)=>void;max?:number}){
  return <div className="context-options multi-options">{options.map(option=>{const disabled=!!max&&selected.length>=max&&!selected.includes(option);return <button key={option} disabled={disabled} className={selected.includes(option)?"selected":""} aria-pressed={selected.includes(option)} onClick={()=>onChange(option)}><span>{selected.includes(option)?"✓":""}</span><b>{option}</b></button>})}</div>;
}

function SourceLink({role}:{role:Role}){
  return <a className="official-role-link" href={role.officialSourceUrl} target="_blank" rel="noreferrer"><span>Official source · {role.company}</span><b>{role.officialRoleTitle}</b><small>Checked {role.statusCheckedDate} ↗</small></a>;
}

export default function WorkstyleExplorer({goHome,goRoles,goCompare}:{goHome:()=>void;goRoles:()=>void;goCompare:(ids:string[])=>void}){
  const [phase,setPhase]=useState<Phase>("intro");const [step,setStep]=useState(0);const [state,setState]=useState<ExplorerState>(emptyState);const [notice,setNotice]=useState("");const hydrated=useRef(false);
  useEffect(()=>{try{const params=new URLSearchParams(location.search);const encoded=params.get("workstyle");const saved=localStorage.getItem(STORAGE_KEY);if(encoded&&/^[ABC]{6}$/.test(encoded)){setState({...emptyState,target:params.get("target")||"Unsure",scenarioAnswers:encoded.split("") as AnswerKey[]});setPhase("result")}else if(saved){const parsed=JSON.parse(saved);setState({...emptyState,...parsed.state});setStep(parsed.step||0);setPhase(parsed.phase||"intro")}}catch{}finally{hydrated.current=true}},[]);
  useEffect(()=>{if(!hydrated.current)return;try{localStorage.setItem(STORAGE_KEY,JSON.stringify({state,step,phase}))}catch{}},[state,step,phase]);
  const result=useMemo(()=>state.scenarioAnswers.length===6?resultForAnswers(state.scenarioAnswers):null,[state.scenarioAnswers]);
  const chooseSingle=(key:keyof ExplorerState,value:string)=>setState(current=>({...current,[key]:value}));
  const toggle=(key:"informationGaps"|"expectations"|"preparation",value:string)=>setState(current=>{const selected=current[key];const exclusive=value==="I am not sure"||value==="I have not started preparing";return {...current,[key]:selected.includes(value)?selected.filter(item=>item!==value):exclusive?[value]:[...selected.filter(item=>item!=="I am not sure"&&item!=="I have not started preparing"),value]}});
  const chooseScenario=(index:number,key:AnswerKey)=>setState(current=>{const next=[...current.scenarioAnswers];next[index]=key;return {...current,scenarioAnswers:next}});
  const valid=step===0?!!state.careerStage:step===1?!!state.target:step===2?state.informationGaps.length>0:step<9?!!state.scenarioAnswers[step-3]:step===9?state.expectations.length>0:state.preparation.length>0;
  const next=()=>{if(!valid)return;if(step<10)setStep(step+1);else{setPhase("result");history.replaceState({},"",resultUrl(state));window.scrollTo({top:0})}};
  const reset=()=>{localStorage.removeItem(STORAGE_KEY);const url=new URL(location.href);url.searchParams.delete("workstyle");url.searchParams.delete("target");history.replaceState({},"",url);setState(emptyState);setStep(0);setPhase("intro");setNotice("")};

  if(phase==="intro")return <div className="workstyle-shell intro-screen"><div className="intro-copy"><span className="kicker">QUANT CAREER REALITY CHECK</span><h1>Connect your context, work preferences and target-role assumptions.</h1><p>Eleven lightweight questions combine your exploration stage, six work scenarios and official JD evidence. The result identifies directions and assumptions worth investigating—not ability or future performance.</p><div className="time-note">◷ About 4–5 minutes · 11 questions · evidence-led</div><div className="intro-actions"><button className="button primary" onClick={()=>setPhase("questions")}>Start the Reality Check →</button><button className="button outline" onClick={goRoles}>Explore verified roles</button></div></div><div className="preview-result-card example-preview"><span>EXAMPLE RESULT — YOUR RESULT WILL VARY</span><ResultArt kind="synth"/><div><b>Strategy Synthesizer</b><small>Research iteration × real-time decision</small></div><p>以下仅为示例，完成测试后将根据你的回答生成结果。</p></div></div>;

  if(phase==="questions"){
    const scenarioIndex=step-3;const scenario=scenarioIndex>=0&&scenarioIndex<6?scenarios[scenarioIndex]:null;
    const layer=step<3?"CAREER CONTEXT":step<9?"WORKSTYLE SCENARIO":"REALITY GAP";
    return <div className="scenario-shell"><div className="scenario-top"><button className="bare" onClick={()=>step?setStep(step-1):setPhase("intro")}>← Back</button><div className="scenario-progress"><span style={{width:`${(step+1)/11*100}%`}}/></div><small>{step+1} / 11</small></div><section className="scenario-card integrated-question"><span className="kicker">{layer}</span>
      {step===0&&<><h1>Where are you currently in your quant-career exploration?</h1><div className="context-options">{careerStageOptions.map(option=><button key={option} className={state.careerStage===option?"selected":""} aria-pressed={state.careerStage===option} onClick={()=>chooseSingle("careerStage",option)}><span>○</span><b>{option}</b></button>)}</div></>}
      {step===1&&<><h1>What role are you currently considering?</h1><p className="question-help">This answer is used only for the evidence comparison. It never changes the Workstyle score.</p><div className="context-options">{targetRoleOptions.map(option=><button key={option} className={state.target===option?"selected":""} aria-pressed={state.target===option} onClick={()=>chooseSingle("target",option)}><span>○</span><b>{option}</b></button>)}</div></>}
      {step===2&&<><h1>What is currently hardest for you to understand?</h1><p className="question-help">Select up to three. These signals only prioritise your next actions.</p><MultiChoice options={informationGapOptions} selected={state.informationGaps} max={3} onChange={value=>toggle("informationGaps",value)}/></>}
      {scenario&&<><h1>{scenario.prompt}</h1><p className="question-help">Choose the activity you would most like to investigate. The displayed letters do not represent fixed dimensions.</p><div className="scenario-options">{scenario.options.map(option=><button key={option.key} className={state.scenarioAnswers[scenarioIndex]===option.key?"selected":""} aria-pressed={state.scenarioAnswers[scenarioIndex]===option.key} onClick={()=>chooseScenario(scenarioIndex,option.key)}><span>{option.key}</span><b>{option.label}</b></button>)}</div></>}
      {step===9&&<><h1>Which tasks do you currently expect your target role to involve most?</h1><MultiChoice options={expectationOptions} selected={state.expectations} onChange={value=>toggle("expectations",value)}/></>}
      {step===10&&<><h1>What are you currently spending most of your preparation time on?</h1><MultiChoice options={preparationOptions} selected={state.preparation} onChange={value=>toggle("preparation",value)}/></>}
      <div className="scenario-actions"><button className="button ghost" onClick={reset}>Restart</button><button className="button primary" disabled={!valid} onClick={next}>{step===10?"See directions worth exploring":"Continue"} →</button></div>
    </section></div>;
  }

  if(!result)return null;const config=result.config;const targetFamily=roleFamilyFor(state.target,config);const familyEvidence=roles.filter(role=>role.normalisedRoleFamily===targetFamily);const selected=evidenceRoles(config,state.target);const actual=advertisedTasks(familyEvidence);const examples=distinctFirmExamples(selected);const supported=state.expectations.filter(item=>actual.includes(item));const needsVerification=state.expectations.filter(item=>item!=="I am not sure"&&!actual.includes(item));const varied=fingerprintTaxonomy.filter(item=>{const count=familyEvidence.filter(role=>item.pattern.test(`${role.responsibilities} ${role.requiredSkills}`)).length;return count>0&&count<familyEvidence.length}).map(item=>item.label).slice(0,3);const notStated=taskTaxonomy.filter(item=>!item.pattern.test(familyEvidence.map(role=>`${role.responsibilities} ${role.requiredSkills}`).join(" "))).map(item=>item.label).slice(0,3);const prep=preparationAnalysis(state,familyEvidence);const actions=nextActions(state,config,selected,actual);const link=resultUrl(state);
  const download=async()=>{const blob=await shareCardBlob(config,result.scores,link);const anchor=document.createElement("a");anchor.href=URL.createObjectURL(blob);anchor.download=`quant-reality-check-${result.id}.png`;anchor.click();setTimeout(()=>URL.revokeObjectURL(anchor.href),1000);setNotice("PNG downloaded.")};
  const copyLink=async()=>{try{await navigator.clipboard.writeText(link)}catch{const input=document.createElement("textarea");input.value=link;document.body.append(input);input.select();document.execCommand("copy");input.remove()}setNotice("Share link copied. Career-context answers stay on this device.")};
  const share=async()=>{const blob=await shareCardBlob(config,result.scores,link);const file=new File([blob],`quant-reality-check-${result.id}.png`,{type:"image/png"});try{if(navigator.share&&navigator.canShare?.({files:[file]})){await navigator.share({title:`Quant Reality Check — ${config.en}`,text:config.description,url:link,files:[file]});return}if(navigator.share){await navigator.share({title:`Quant Reality Check — ${config.en}`,text:config.description,url:link});return}}catch(error){if((error as Error).name==="AbortError")return}await download();await copyLink()};

  return <div className={`workstyle-results result-theme-${config.illustration}`}>
    <section className="primary-result-section"><div className="snapshot-hero"><div className="snapshot-art"><ResultArt kind={config.illustration}/></div><div><div className="section-index">01 · CURRENT WORKSTYLE SNAPSHOT</div><span className="kicker">CURRENT WORKSTYLE SNAPSHOT</span><h1>{config.en}</h1><h2>{config.zh}</h2><p>{config.description}</p><div className="tendency-pills"><span>Worth exploring first · {config.directions.join(" + ")}</span></div><button className="button primary" onClick={share}>Share Result</button></div></div><div className="diagnosis-note"><b>This is a Current Workstyle Snapshot, not a personality diagnosis or a career verdict.</b><span>The title and graphic summarise six task-preference choices; they do not establish ability, suitability or future performance.</span></div><div className="result-block snapshot-explanation"><h2>How the snapshot was produced</h2><div className="answer-trace">{state.scenarioAnswers.map((answer,index)=>{const option=scenarios[index].options.find(item=>item.key===answer)!;return <article key={scenarios[index].id}><span>0{index+1}</span><div><b>{scenarios[index].prompt}</b><p>“{option.label}”</p></div></article>})}</div><div className="workstyle-bars">{(["research","decision","systems"] as const).map(key=><div key={key}><div><b>{dimensions[key].label}</b><span>{result.scores[key]} signal points</span></div><i><span style={{width:`${Math.max(4,result.scores[key]/12*100)}%`,background:dimensions[key].color}}/></i></div>)}</div><p className="rule-note">Prototype heuristic: each scenario adds two points to its configured dimension. The A/B/C order changes across questions. This rule has not been statistically or psychometrically validated.</p><p className="target-exclusion">Target role—<b>{state.target||"Not included in shared link"}</b>—did not participate in the calculation.</p></div></section>
    <section className="result-block primary-result-section"><div className="section-index">02 · YOUR CURRENT CONTEXT</div><h2>Where you are now changes what to verify next</h2><div className="context-summary"><article><small>CURRENT EXPLORATION STAGE</small><h3>{state.careerStage||"Not included in shared link"}</h3><small>TARGET ROLE</small><h3>{state.target||"Not included in shared link"}</h3></article><article><small>HARDEST INFORMATION TO UNDERSTAND</small><div className="summary-chips">{state.informationGaps.length?state.informationGaps.map(item=><span key={item}>{item}</span>):<span>Not included in shared link</span>}</div></article></div><p>Career Context prioritises evidence and next actions. It does not change the Workstyle calculation or disqualify a direction.</p></section>
    <section className="result-block primary-result-section"><div className="section-index">03 · YOUR CURRENT ASSUMPTION</div><span className="kicker">MENTAL MODEL</span><h2>What you currently expect this role to involve</h2><div className="assumption-list">{state.expectations.length?state.expectations.map(item=><span key={item}>{item}</span>):<span>Not included in shared link</span>}</div><p className="section-intro">This is your current picture, not a factual claim. The next section checks it against the reviewed official wording while preserving company variation.</p></section>
    <section className="result-block primary-result-section"><div className="section-index">04 · EVIDENCE-BASED REALITY CHECK</div><h2>What the reviewed {targetFamily} descriptions support—and what they cannot settle</h2><div className="gap-analysis evidence-status-grid"><article className="aligned"><small>SUPPORTED BY THE REVIEWED JDS</small>{supported.length?<ul>{supported.map(item=><li key={item}>{item}</li>)}</ul>:<p>No selected assumption has a direct label-level match yet.</p>}</article><article className="verify"><small>NEEDS FURTHER VERIFICATION</small>{needsVerification.length?<ul>{needsVerification.map(item=><li key={item}>{item} — not found in the reviewed wording; absence is not evidence that the task never occurs.</li>)}</ul>:<p>Team-level time allocation and lived day-to-day work still require practitioner or team evidence.</p>}</article><article className="variation"><small>VARIES SUBSTANTIALLY BY COMPANY</small><ul>{varied.map(item=><li key={item}>{item}</li>)}</ul></article><article className="prepare"><small>NOT STATED IN THE REVIEWED EVIDENCE</small>{notStated.length?<ul>{notStated.map(item=><li key={item}>{item}</li>)}</ul>:<p>No additional taxonomy item is absent across every reviewed role in this family. This does not make every item universal.</p>}</article></div><div className="official-link-grid">{selected.slice(0,3).map(role=><SourceLink role={role} key={role.id}/>)}</div></section>
    <section className="result-block primary-result-section"><div className="section-index">05 · TASK FINGERPRINT</div><h2>The same role family can have different advertised task combinations</h2><div className="fingerprint-grid"><div className="fingerprint-legend">{fingerprintTaxonomy.map(item=><span key={item.label}>{item.label}</span>)}</div>{examples.map(role=>{const marks=fingerprintFor(role);return <article key={role.id}><div><b>{role.company}</b><small>{role.officialRoleTitle}</small></div><div>{fingerprintTaxonomy.map(item=><span key={item.label} className={marks.includes(item.label)?"present":"absent"} title={marks.includes(item.label)?"Explicit wording found":"Not stated in the reviewed wording"}>{marks.includes(item.label)?"●":"○"}<i>{item.label}</i></span>)}</div></article>})}</div><p className="rule-note">A filled marker means explicit wording was detected in that reviewed description. An open marker means “not stated in the reviewed wording”, not “not required” or “never performed”.</p></section>
    <section className="result-block primary-result-section"><div className="section-index">06 · FIRM VARIATION</div><h2>Two to three official examples from the same role family</h2><p className="variation-statement">Among the reviewed sources, a title is a starting point—not a universal definition.</p><div className="firm-variation-grid">{examples.map(role=><article key={role.id}><span>{role.company}</span><h3>{role.officialRoleTitle}</h3><dl><dt>Location</dt><dd>{role.location}</dd><dt>Level</dt><dd>{role.level}</dd><dt>Campus or experienced hire</dt><dd>Not stated in reviewed source</dd><dt>Application status</dt><dd>{role.applicationStatus} · {role.statusCaveat}</dd><dt>Checked date</dt><dd>{role.statusCheckedDate}</dd><dt>Main advertised tasks</dt><dd>{role.responsibilities}</dd></dl><SourceLink role={role}/></article>)}</div><button className="button outline compare-direct" onClick={()=>goCompare(examples.map(role=>role.id))}>Compare these roles across firms →</button></section>
    <section className="result-block primary-result-section"><div className="section-index">07 · PREPARATION REALITY GAP</div><h2>Compare current preparation with wording in the reviewed descriptions</h2><div className="preparation-summary"><b>Your current preparation focus</b><p>{state.preparation.length?state.preparation.join(" · "):"Not included in shared link"}</p></div><div className="gap-analysis preparation-gap-grid"><article className="aligned"><small>RELEVANT PREPARATION</small>{prep.relevant.length?<ul>{prep.relevant.map(item=><li key={item}>{item}</li>)}</ul>:<p>No direct wording match established yet.</p>}</article><article className="prepare"><small>POSSIBLE MISSING AREA</small>{prep.possible.length?<ul>{prep.possible.map(item=><li key={item}>{item}</li>)}</ul>:<p>Use the exact company requirements to identify a concrete area.</p>}</article><article className="verify"><small>VERIFY FOR THIS SPECIFIC COMPANY</small><p>Check degree, grades, graduation timing, working rights and live application status in the exact official source.</p></article><article className="variation"><small>LOWER PRIORITY IN THE REVIEWED EVIDENCE</small>{prep.lower.length?<ul>{prep.lower.map(item=><li key={item}>{item}</li>)}</ul>:<p>No selected preparation area falls into this category.</p>}</article></div></section>
    <section className="result-block primary-result-section"><div className="section-index">08 · THREE NEXT ACTIONS</div><h2>Exactly three evidence-led steps</h2><div className="next-three">{actions.map((action,index)=><article key={action}><span>0{index+1}</span><p>{action}</p></article>)}</div></section>
    <section className="share-panel"><div><span className="kicker">SHARE WITHOUT SENSITIVE DATA</span><h2>Your 1080 × 1350 result card</h2><p>The image contains the Workstyle Snapshot only. Career stage, information gaps and preparation answers stay on this device.</p></div><div><button className="button primary" onClick={download}>Download PNG</button><button className="button outline" onClick={share}>Share</button><button className="button outline" onClick={copyLink}>Copy Link</button></div>{notice&&<small role="status">{notice}</small>}</section>
    <div className="result-footer-actions"><button className="button outline" onClick={reset}>Retake Reality Check</button><button className="button outline" onClick={goRoles}>Explore verified roles</button><button className="bare" onClick={goHome}>Back to home</button></div>
  </div>;
}
