"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { roles, type Role, type RoleFamily } from "./data";
import {
  careerStageOptions, dimensions, expectationOptions, informationGapOptions,
  preparationOptions, resultForAnswers, scenarios, targetRoleOptions,
} from "./workstyle";
import { actionPlan, stageContext, targetAlignment } from "./result-context";

type AnswerKey = "A"|"B"|"C";
type Phase = "intro"|"questions"|"result";
type ResultConfig = ReturnType<typeof resultForAnswers>["config"];
type ExplorerState = {
  careerStage:string; target:string; informationGaps:string[]; scenarioAnswers:AnswerKey[];
  expectations:string[]; preparation:string[];
};

const STORAGE_KEY = "qrc-integrated-reality-check-v2";
const emptyState:ExplorerState = {careerStage:"",target:"",informationGaps:[],scenarioAnswers:[],expectations:[],preparation:[]};
const informationGapTitles=["Day-to-day work","Math and coding requirements","Role differences","Fit with my background","Interview priorities","Recruitment timelines","Eligibility and location","Trustworthy sources"];

function visibleInformationGap(value:string){const index=informationGapOptions.indexOf(value);return index>=0?informationGapTitles[index]:value}

function resultUrl(state:ExplorerState){
  const url=new URL(window.location.href);
  url.searchParams.set("workstyle",state.scenarioAnswers.join(""));
  url.searchParams.set("target",state.target||"Unsure");
  return url.toString();
}

function roleFamilyFor(target:string,config:ResultConfig):RoleFamily{
  if(target==="Quantitative Trading"||target==="Quantitative Research")return target;
  if(target==="Software / Quantitative Engineering")return "Software Engineering";
  return config.directions[0] as RoleFamily;
}

function evidenceRoles(config:ResultConfig,target:string){
  const family=roleFamilyFor(target,config);
  const sameFamily=roles.filter(role=>role.normalisedRoleFamily===family);
  const preferred=config.evidenceQueries.map((query:{company:string;title:string})=>roles.find(role=>role.company===query.company&&role.officialRoleTitle.includes(query.title))).filter(Boolean) as Role[];
  const ordered=[...sameFamily,...preferred];
  return [...new Map(ordered.map(role=>[role.id,role])).values()].slice(0,5);
}

const taskTaxonomy = [
  {label:"Analysing datasets",pattern:/data|statistical analysis|historical/i},
  {label:"Developing and validating models",pattern:/model|signal|backtest|hypothesis|research/i},
  {label:"Making real-time risk decisions",pattern:/real-time|risk decision|fast market decision|execute trading/i},
  {label:"Monitoring markets",pattern:/monitor|market signal|market data|market making/i},
  {label:"Writing production software",pattern:/production|software|develop systems|build systems|code/i},
  {label:"Optimising latency and system performance",pattern:/latency|performance|high-performance|scaling|efficiency/i},
  {label:"Building data pipelines",pattern:/pipeline|data engineering|market-data decoder|infrastructure/i},
  {label:"Pricing, liquidity or execution work",pattern:/pric|liquidity|execution|market mak|options|arbitrage/i},
  {label:"Communicating research or trading decisions",pattern:/communicat|collaborat|present/i},
];

const fingerprintTaxonomy = [
  {label:"Research and model validation",pattern:/research|model|signal|backtest|statistical|machine learning|\bML\b/i},
  {label:"Real-time decision making",pattern:/real-time|decision|trading intuition|mock trading|simulation|execute strateg/i},
  {label:"Software and production systems",pattern:/production|software|code|developer|high-performance implementation|trading system/i},
  {label:"Data and infrastructure",pattern:/dataset|historical data|pipeline|infrastructure|market data|data engineering/i},
  {label:"Risk and liquidity",pattern:/risk|liquidity|market making|volatility|options/i},
  {label:"Pricing and execution",pattern:/pric|execution|arbitrage|trade execution|automated trading/i},
  {label:"Communication and collaboration",pattern:/communicat|collaborat|team|present/i},
];

const preparationTaxonomy = [
  {label:"Probability and mathematics",pattern:/probability|mathemat|quantitative|stochastic|game theory/i},
  {label:"Statistics and machine learning",pattern:/statistical|statistics|machine learning|\bML\b|model/i},
  {label:"Python and data analysis",pattern:/Python|data analys|dataset/i},
  {label:"Algorithms and data structures",pattern:/algorithm|data structure|problem solving/i},
  {label:"C++ and systems programming",pattern:/C\+\+|systems programming|concurrency|performance|low-latency|high-performance/i},
  {label:"Market knowledge",pattern:/market|trading|options|liquidity|pricing|execution/i},
  {label:"Mental maths or trading games",pattern:/mental math|trading game|competitive activit/i},
  {label:"Interview questions",pattern:/interview|assessment/i},
  {label:"Networking and company research",pattern:/network|company research/i},
];

function advertisedTasks(selected:Role[]){
  const source=selected.map(role=>`${role.responsibilities} ${role.requiredSkills}`).join(" ");
  return taskTaxonomy.filter(task=>task.pattern.test(source)).map(task=>task.label);
}

function distinctFirmExamples(selected:Role[]){
  const seen=new Set<string>();
  return selected.filter(role=>!seen.has(role.company)&&seen.add(role.company)).slice(0,3);
}

function fingerprintFor(role:Role){
  const source=`${role.responsibilities} ${role.requiredSkills}`;
  return fingerprintTaxonomy.filter(item=>item.pattern.test(source)).map(item=>item.label);
}

function preparationAnalysis(state:ExplorerState,selected:Role[]){
  const source=selected.map(role=>`${role.responsibilities} ${role.requiredSkills}`).join(" ");
  const relevant=state.preparation.filter(item=>preparationTaxonomy.find(entry=>entry.label===item)?.pattern.test(source));
  const lower=state.preparation.filter(item=>item!=="I have not started preparing"&&!relevant.includes(item));
  const possible=preparationTaxonomy.filter(item=>item.pattern.test(source)&&!state.preparation.includes(item.label)).map(item=>item.label).slice(0,3);
  return {relevant,lower,possible};
}

function nextActions(state:ExplorerState,config:ResultConfig,selected:Role[],actual:string[]){
  const first=selected[0],second=selected[1];const plan=actionPlan(state);const direction=config.directions[0];
  const stageAction=plan.stage==="early"?`Compare one ${direction} JD with one adjacent role family before choosing a title.`:plan.stage==="preparing"?`Inspect the exact ${first.company} and ${second.company} JDs, including live status and explicit eligibility wording, before applying.`:plan.stage==="applied"?`Compare your application or interview experience with the responsibilities and requirements in the exact ${first.company} JD.`:plan.stage==="comparing"?`Use Compare to inspect ${first.company} and ${second.company} within the same role family without reducing them to a score.`:`Compare your lived task mix with the ${first.company} JD and note one role-boundary assumption that changed.`;
  const gapAction=plan.gapType==="day-to-day"?`Build a two-column task comparison for ${first.company} and ${second.company}; mark shared tasks and firm-specific wording.`:plan.gapType==="requirements"?`Create an essential / preferred / not-stated matrix from the two reviewed JDs; keep “not stated” distinct from “not required”.`:plan.gapType==="timeline"?`Open both official application pages and verify the live status, campaign year and any recruitment-timeline wording.`:plan.gapType==="interview"?`Compare one interview topic you are prioritising with the advertised requirements in the ${first.company} and ${second.company} JDs.`:plan.gapType==="eligibility"?`Verify degree, graduation timing, grades and working-right wording on the exact ${first.company} official page.`:plan.gapType==="sources"?`Check the accessed date and current official page for both roles before relying on any secondary career advice.`:`Compare one shared task and one company-specific difference across the two official descriptions.`;
  const uncovered=actual.find(task=>!state.expectations.includes(task));
  const preparationAction=plan.preparationType==="starter"?`Try one 45-minute task resembling “${uncovered||actual[0]||"reviewing a small dataset"}” and record what remains unclear.`:plan.preparationType==="assumption"?`Ask one practitioner whether “${actual[0]||"the advertised task mix"}” appears in their actual week; treat one answer as context, not a universal rule.`:plan.preparationType==="compare-preparation"?`Compare your current focus—${state.preparation.slice(0,2).join(" and ")}—against the repeated requirements in the ${first.company} and ${second.company} JDs.`:`Try a small role-relevant task, then compare the work with your current expectation rather than treating it as an ability test.`;
  return [stageAction,gapAction,preparationAction];
}

function ResultArt({kind}:{kind:string}){
  if(kind==="signal")return <svg className="result-art art-signal" viewBox="0 0 420 280" role="img" aria-label="Signal Explorer: irregular data points, waveform and magnifier"><defs><pattern id="dots-signal" width="22" height="22" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1.5" fill="#7C6CF2" opacity=".3"/></pattern></defs><path className="art-bg" d="M15 42 314 14l91 92-38 154-303 7L8 171Z"/><path fill="url(#dots-signal)" d="M15 42 314 14l91 92-38 154-303 7L8 171Z"/><path className="stroke-a" d="M32 183c45 0 41-104 90-104s54 132 105 132 49-166 97-166"/><g className="stroke-b"><circle cx="314" cy="96" r="46"/><path d="m348 130 42 42"/></g>{[[63,183],[122,79],[227,211],[324,45]].map(([x,y])=><circle key={`${x}`} cx={x} cy={y} r="7" className="dot"/>)}</svg>;
  if(kind==="market")return <svg className="result-art art-market" viewBox="0 0 420 280" role="img" aria-label="Market Navigator: vertical compass, arrows and radar pulses"><rect className="art-bg" x="70" y="8" width="280" height="264" rx="110"/><g className="pulse"><ellipse cx="210" cy="142" rx="145" ry="62"/><ellipse cx="210" cy="142" rx="102" ry="42"/><ellipse cx="210" cy="142" rx="58" ry="24"/></g><path className="needle" d="m210 22 34 119-34 117-34-117Z"/><path className="arrow" d="m210 24 24 92-24 25-24-25Z"/><path className="ticks" d="M36 142h56m236 0h56M210 5v35m0 204v31"/></svg>;
  if(kind==="systems")return <svg className="result-art art-systems" viewBox="0 0 420 280" role="img" aria-label="Systems Builder: modules, nodes, circuits and data pipeline"><defs><pattern id="grid-systems" width="24" height="24" patternUnits="userSpaceOnUse"><path d="M24 0H0v24" fill="none" stroke="#31C7B5" opacity=".15"/></pattern></defs><rect className="art-bg" x="5" y="5" width="410" height="270" rx="12"/><rect x="5" y="5" width="410" height="270" rx="12" fill="url(#grid-systems)"/><g className="modules"><rect x="38" y="42" width="96" height="64" rx="8"/><rect x="162" y="108" width="96" height="64" rx="8"/><rect x="286" y="174" width="96" height="64" rx="8"/></g><path className="circuit" d="M134 74h48v34m76 32h48v34M86 106v98h76m48-96V52h76m-76 120v62"/><g className="nodes"><circle cx="86" cy="204" r="8"/><circle cx="286" cy="52" r="8"/><circle cx="210" cy="234" r="8"/></g></svg>;
  if(kind==="synth")return <svg className="result-art art-synth" viewBox="0 0 420 280" role="img" aria-label="Strategy Synthesizer: two contrasting paths crossing"><path className="art-bg" d="M16 21h388v238H16z"/><path className="path-one" d="M24 224C110 224 117 48 210 48s94 176 186 176"/><path className="path-two" d="M24 54c86 0 98 170 186 170S304 54 396 54"/><path className="cross" d="m182 112 56 56m0-56-56 56"/><circle cx="210" cy="140" r="23" className="hub"/></svg>;
  if(kind==="bridge")return <svg className="result-art art-bridge" viewBox="0 0 420 280" role="img" aria-label="Model-to-Market Builder: model flowing over a bridge into a system"><path className="art-bg" d="M8 20h404v240H8z"/><g className="model"><circle cx="76" cy="137" r="52"/><path d="M45 146h20l13-30 18 46 14-25h19"/></g><path className="flow" d="M128 137h46c20 0 20-52 42-52s24 104 48 104h28"/><path className="bridge-deck" d="M145 190h150M164 190v36m38-36v36m38-36v36m38-36v36"/><g className="system"><rect x="292" y="88" width="98" height="98" rx="12"/><path d="M310 112h62m-62 25h44m-44 25h55"/></g></svg>;
  if(kind==="execution")return <svg className="result-art art-execution" viewBox="0 0 420 280" role="img" aria-label="Execution Architect: diagonal lightning and low-latency circuit"><path className="art-bg" d="M3 214 310 4l107 61-306 211Z"/><path className="speed-lines" d="M22 222 190 106M72 260 240 144M180 270 362 144"/><path className="bolt" d="m242 18-119 142h87l-35 105 130-157h-91Z"/><path className="circuit" d="M42 66h86v42m165 80h85m-43 0v-42M44 238h80v-43"/><g className="nodes"><circle cx="128" cy="108" r="7"/><circle cx="335" cy="146" r="7"/><circle cx="124" cy="195" r="7"/></g></svg>;
  return <svg className="result-art art-prism" viewBox="0 0 420 280" role="img" aria-label="Open Explorer: prism and three radiating paths"><defs><radialGradient id="prism-glow"><stop stopColor="#8A87A8" stopOpacity=".45"/><stop offset="1" stopColor="#171B27" stopOpacity="0"/></radialGradient></defs><circle cx="210" cy="140" r="136" fill="url(#prism-glow)"/><path className="prism" d="m210 38-84 168h168Z"/><path className="incoming" d="M14 140h140"/><path className="ray ray-a" d="m266 140 127-83"/><path className="ray ray-b" d="m266 140 142 5"/><path className="ray ray-c" d="m266 140 119 91"/><g className="orbit"><circle cx="210" cy="140" r="112"/><circle cx="210" cy="140" r="76"/></g></svg>;
}

function LineIcon({name}:{name:string}){
  const paths:Record<string,React.ReactNode>={
    compass:<><circle cx="12" cy="12" r="9"/><path d="m15 9-2 4-4 2 2-4 4-2Z"/></>,
    compare:<><path d="M7 7h11m0 0-3-3m3 3-3 3M17 17H6m0 0 3 3m-3-3 3-3"/></>,
    target:<><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3m10-10h-3M5 12H2"/></>,
    briefcase:<><rect x="3" y="7" width="18" height="12" rx="2"/><path d="M8 7V5h8v2m-13 5h18"/></>,
    message:<><path d="M5 18 3 21v-5a8 8 0 1 1 3 3Z"/></>,
    badge:<><path d="m12 2 3 3 4 .5.5 4L22 12l-2.5 2.5-.5 4-4 .5-3 3-3-3-4-.5-.5-4L2 12l2.5-2.5.5-4L9 5Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></>,
    data:<><path d="M4 5c0-1.1 3.6-2 8-2s8 .9 8 2-3.6 2-8 2-8-.9-8-2Zm0 0v6c0 1.1 3.6 2 8 2s8-.9 8-2V5m-16 6v6c0 1.1 3.6 2 8 2s8-.9 8-2v-6"/></>,
    code:<><path d="m8 8-4 4 4 4m8-8 4 4-4 4m-2-10-4 12"/></>,
    market:<><path d="M4 18V6m0 12h16M7 15l4-5 3 3 5-7"/></>,
    research:<><circle cx="10" cy="10" r="6"/><path d="m14.5 14.5 5 5M8 10h4m-2-2v4"/></>,
    shield:<><path d="M12 3 4 6v5c0 5 3.4 8.4 8 10 4.6-1.6 8-5 8-10V6l-8-3Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></>,
  };
  return <svg className="line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]||paths.compass}</svg>;
}

function ScenarioVisual({index}:{index:number}){
  const labels=["Signal decay","Choose a task","Feedback loop","Reversible path","Evidence of progress","Learning systems"];
  return <div className={`micro-scene scene-${index}`} aria-hidden="true"><svg viewBox="0 0 360 260">
    <rect x="18" y="18" width="324" height="224" rx="20" className="scene-frame"/>
    {index===0&&<><path d="M42 176c48-8 72-72 114-75s50 73 81 56 32-73 76-87" className="scene-main"/><path d="M42 194h271" className="scene-risk"/><path d="M54 218h58m12 0h58m12 0h58" className="scene-data"/></>}
    {index===1&&<>{[42,137,232].map((x,i)=><g key={x}><rect x={x} y="76" width="78" height="108" rx="13" className={i===1?"scene-tile active":"scene-tile"}/>{i===0?<path d={`M${x+15} 143h48m-42-19h36m-28-20h20`} className="scene-mark"/>:i===1?<><circle cx={x+39} cy="125" r="21" className="scene-mark"/><path d={`m${x+54} 140 12 12`} className="scene-mark"/></>:<path d={`M${x+14} 153c15-58 31-58 48 0M${x+14} 119h48`} className="scene-mark"/>}</g>)}</>}
    {index===2&&<><circle cx="180" cy="130" r="34" className="scene-hub"/><path d="M180 96V49m-27 62-68-42m68 80-68 42m122-80 68-42m-68 80 68 42" className="scene-main"/><circle cx="180" cy="49" r="10"/><rect x="58" y="56" width="26" height="26" rx="5"/><path d="m267 63 16 12-16 12"/></>}
    {index===3&&<><path d="M53 130h70m0 0 55-60m-55 60 55 60m0-120h124m-124 120h124" className="scene-main"/><circle cx="123" cy="130" r="12" className="scene-hub"/><path d="m275 60 18 10-18 10m0 100 18 10-18 10" className="scene-risk"/></>}
    {index===4&&<><rect x="46" y="66" width="75" height="126" rx="12"/><path d="M62 164h43M62 141h43M62 118h43" className="scene-data"/><circle cx="180" cy="129" r="43" className="scene-hub"/><path d="m165 130 12 12 24-29" className="scene-main"/><path d="M239 179 277 80l37 99Z" className="scene-risk"/></>}
    {index===5&&<><circle cx="88" cy="130" r="42"/><circle cx="180" cy="130" r="42"/><circle cx="272" cy="130" r="42"/><path d="m72 130 13 13 22-28M159 147c10-48 31-48 42 0m53-17h36m-18-18v36" className="scene-main"/></>}
  </svg><span>{labels[index]}</span></div>;
}

function RoleTranslationMap(){
  return <div className="translation-map" aria-label="Role Translation Map showing company titles translated into comparable evidence, reality gaps and next actions"><div className="translation-heading"><span>ROLE TRANSLATION MAP</span><small>How the product turns fragmented titles into comparable evidence</small></div><div className="translation-flow"><div className="translation-roles"><span>Quantitative Researcher</span><span>Quantitative Trader</span><span>Software Engineer</span></div><svg viewBox="0 0 120 180" aria-hidden="true"><path d="M4 28C48 28 42 90 116 90M4 90h112M4 152c44 0 38-62 112-62"/></svg><div className="translation-signals"><span>Research</span><span>Decisions</span><span>Systems</span><span>Data</span><span>Risk</span></div><svg viewBox="0 0 120 180" aria-hidden="true"><path d="M4 90h112"/></svg><div className="translation-outcomes"><span>Comparable role evidence</span><span>Reality gaps</span><span>Next actions</span></div></div><p>Official titles stay intact. Shared task signals make differences and overlaps easier to investigate.</p></div>;
}

function wrapText(ctx:CanvasRenderingContext2D,text:string,x:number,y:number,maxWidth:number,lineHeight:number,maxLines=6){
  const words=text.split(" ");let line="";let lines=0;
  for(const word of words){const test=`${line}${word} `;if(ctx.measureText(test).width>maxWidth&&line){ctx.fillText(line.trim(),x,y);line=`${word} `;y+=lineHeight;lines++;if(lines>=maxLines-1)break}else line=test}
  if(line&&lines<maxLines)ctx.fillText(line.trim(),x,y);return y;
}

function drawCanvasIdentity(ctx:CanvasRenderingContext2D,config:ResultConfig){
  const kind=config.illustration;ctx.save();ctx.translate(540,380);ctx.lineWidth=13;ctx.lineCap="round";ctx.lineJoin="round";ctx.strokeStyle=config.accent;ctx.fillStyle=config.accent2;
  if(kind==="signal"){ctx.beginPath();ctx.moveTo(-360,65);ctx.bezierCurveTo(-210,65,-205,-170,-55,-70);ctx.bezierCurveTo(70,15,105,-190,255,-120);ctx.stroke();ctx.beginPath();ctx.arc(235,-88,92,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(300,-23);ctx.lineTo(365,42);ctx.stroke();[[-310,65],[-55,-70],[70,15]].forEach(([x,y])=>{ctx.beginPath();ctx.arc(x,y,14,0,Math.PI*2);ctx.fill()})}
  else if(kind==="market"){ctx.strokeStyle=config.accent;[190,125,62].forEach(r=>{ctx.beginPath();ctx.ellipse(0,0,r,r*.42,0,0,Math.PI*2);ctx.stroke()});ctx.fillStyle=config.accent2;ctx.beginPath();ctx.moveTo(0,-240);ctx.lineTo(55,0);ctx.lineTo(0,215);ctx.lineTo(-55,0);ctx.closePath();ctx.fill()}
  else if(kind==="systems"){ctx.strokeStyle=config.accent;ctx.lineWidth=9;[-250,-55,140].forEach((x,i)=>ctx.strokeRect(x,(i-1)*72-58,145,116));ctx.beginPath();ctx.moveTo(-105,-72);ctx.lineTo(-35,-72);ctx.lineTo(-35,0);ctx.lineTo(-55,0);ctx.moveTo(90,0);ctx.lineTo(160,0);ctx.lineTo(160,72);ctx.stroke()}
  else if(kind==="synth"){ctx.strokeStyle=config.accent;ctx.beginPath();ctx.moveTo(-360,155);ctx.bezierCurveTo(-140,155,-120,-190,0,-70);ctx.bezierCurveTo(130,55,160,150,360,150);ctx.stroke();ctx.strokeStyle=config.accent2;ctx.beginPath();ctx.moveTo(-360,-145);ctx.bezierCurveTo(-130,-145,-115,170,0,105);ctx.bezierCurveTo(130,30,155,-145,360,-145);ctx.stroke()}
  else if(kind==="bridge"){ctx.strokeStyle=config.accent;ctx.beginPath();ctx.arc(-280,-25,86,0,Math.PI*2);ctx.stroke();ctx.strokeStyle=config.accent2;ctx.strokeRect(200,-105,170,160);ctx.beginPath();ctx.moveTo(-194,-25);ctx.bezierCurveTo(-55,-25,-55,-155,45,-90);ctx.bezierCurveTo(105,-52,100,-25,200,-25);ctx.stroke();ctx.beginPath();ctx.moveTo(-170,95);ctx.lineTo(200,95);ctx.stroke()}
  else if(kind==="execution"){ctx.strokeStyle=config.accent;ctx.beginPath();ctx.moveTo(45,-255);ctx.lineTo(-145,20);ctx.lineTo(-20,20);ctx.lineTo(-70,235);ctx.lineTo(155,-80);ctx.lineTo(25,-80);ctx.closePath();ctx.stroke();ctx.strokeStyle=config.accent2;ctx.beginPath();ctx.moveTo(-360,210);ctx.lineTo(300,-210);ctx.stroke()}
  else{ctx.strokeStyle=config.accent;ctx.beginPath();ctx.moveTo(0,-220);ctx.lineTo(-190,145);ctx.lineTo(190,145);ctx.closePath();ctx.stroke();[[340,-150],[370,20],[320,205]].forEach(([x,y],i)=>{ctx.strokeStyle=[config.accent,"#6CAEA6","#B39A72"][i];ctx.beginPath();ctx.moveTo(70,0);ctx.lineTo(x,y);ctx.stroke()})}
  ctx.restore();
}

async function shareCardBlob(config:ResultConfig,directions:string[],signals:string[],url:string){
  if(document.fonts?.ready)await document.fonts.ready;
  const canvas=document.createElement("canvas");canvas.width=1080;canvas.height=1350;const ctx=canvas.getContext("2d");if(!ctx)throw new Error("Canvas is unavailable");
  ctx.fillStyle="#080E1A";ctx.fillRect(0,0,1080,1350);ctx.fillStyle=config.background;ctx.beginPath();ctx.roundRect(70,70,940,1210,42);ctx.fill();
  if(config.illustration==="market"){ctx.fillStyle=config.accent;ctx.fillRect(70,70,940,82)}else if(config.illustration==="systems"){for(let x=70;x<1010;x+=94){ctx.fillStyle=x%188===70?config.accent:config.accent2;ctx.fillRect(x,70,72,28)}}else if(config.illustration==="execution"){ctx.fillStyle=config.accent;ctx.beginPath();ctx.moveTo(70,70);ctx.lineTo(1010,70);ctx.lineTo(790,190);ctx.lineTo(70,190);ctx.closePath();ctx.fill()}else if(config.illustration==="bridge"){ctx.fillStyle=config.accent;ctx.fillRect(70,70,470,76);ctx.fillStyle=config.accent2;ctx.fillRect(540,70,470,76)}else{ctx.fillStyle=config.accent;ctx.fillRect(70,70,18,190)}
  drawCanvasIdentity(ctx,config);
  ctx.textAlign="left";ctx.fillStyle="#58D6C1";ctx.font="700 25px Arial";ctx.fillText("Q  ·  QUANT REALITY CHECK",120,145);
  ctx.fillStyle="#F4F7FB";ctx.font="700 68px Arial";ctx.fillText(config.en,120,650);
  ctx.font="30px Arial";ctx.fillStyle="#B5C0D1";wrapText(ctx,config.description,120,720,840,42,4);
  ctx.fillStyle="#8B78FF";ctx.font="700 23px Arial";ctx.fillText(directions.length?"DIRECTIONS WORTH EXPLORING":"COMPARISON SET",120,885);
  ctx.fillStyle="#F4F7FB";ctx.font="700 32px Arial";wrapText(ctx,directions.length?directions.join("  +  "):"Research  +  Trading  +  Engineering",120,933,840,42,2);
  ctx.fillStyle="#8491A6";ctx.font="700 21px Arial";ctx.fillText("TASK-PREFERENCE SIGNALS",120,1045);
  signals.slice(0,3).forEach((signal,index)=>{const y=1092+index*52;ctx.fillStyle="#172238";ctx.beginPath();ctx.roundRect(120,y-30,820,42,21);ctx.fill();ctx.fillStyle="#F4F7FB";ctx.font="22px Arial";ctx.fillText(signal,142,y)});
  ctx.fillStyle="#8491A6";ctx.font="21px Arial";ctx.fillText(new URL(url).host||"Local prototype",120,1254);ctx.textAlign="right";ctx.fillText("Exploration guide, not a career verdict",960,1254);
  return await new Promise<Blob>((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(new Error("PNG generation failed")),"image/png"));
}

function ShareCard({src,title}:{src:string;title:string}){
  return <div className="share-card-preview" style={{aspectRatio:"4 / 5"}}>{src?<img src={src} alt={`Share card preview for ${title}`}/>:<div className="share-generating"><span className="spinner"/><b>Generating your result card…</b><small>Preparing a private, shareable 1080 × 1350 image.</small></div>}</div>;
}

function ShareModal({open,onClose,config,directions,signals,link,resultId}:{open:boolean;onClose:()=>void;config:ResultConfig;directions:string[];signals:string[];link:string;resultId:string}){
  const [src,setSrc]=useState("");const [blob,setBlob]=useState<Blob|null>(null);const [feedback,setFeedback]=useState("");const [busy,setBusy]=useState(false);const dialogRef=useRef<HTMLDivElement>(null);const closeRef=useRef<HTMLButtonElement>(null);
  useEffect(()=>{if(!open)return;let active=true;setSrc("");setBlob(null);setFeedback("");setBusy(true);shareCardBlob(config,directions,signals,link).then(async next=>{if(!active)return;setBlob(next);setSrc(await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(reader.error);reader.readAsDataURL(next)}));setFeedback("Result card ready.")}).catch(()=>active&&setFeedback("We could not generate the image. Close this window and try again.")).finally(()=>active&&setBusy(false));requestAnimationFrame(()=>closeRef.current?.focus());return()=>{active=false}},[open,config,directions.join("|"),signals.join("|"),link]);
  useEffect(()=>{if(!open)return;const key=(event:KeyboardEvent)=>{if(event.key==="Escape")onClose();if(event.key!=="Tab")return;const focusable=dialogRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]),a[href]');if(!focusable?.length)return;const first=focusable[0],last=focusable[focusable.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus()}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus()}};document.addEventListener("keydown",key);return()=>document.removeEventListener("keydown",key)},[open,onClose]);
  if(!open)return null;
  const file=blob?new File([blob],`quant-reality-check-${resultId}.png`,{type:"image/png"}):null;const canFileShare=!!(file&&navigator.share&&navigator.canShare?.({files:[file]}));
  const download=()=>{if(!blob)return;const objectUrl=URL.createObjectURL(blob);const anchor=document.createElement("a");anchor.href=objectUrl;anchor.download=`quant-reality-check-${resultId}.png`;anchor.click();setTimeout(()=>URL.revokeObjectURL(objectUrl),1000);setFeedback("PNG downloaded.")};
  const copy=async()=>{try{await navigator.clipboard.writeText(link)}catch{const input=document.createElement("textarea");input.value=link;document.body.append(input);input.select();document.execCommand("copy");input.remove()}setFeedback("Result link copied. Context answers remain on this device.")};
  const share=async()=>{if(!file||!canFileShare)return;try{await navigator.share({title:`Quant Reality Check — ${config.en}`,text:"Exploration guide, not a career verdict",files:[file]});setFeedback("Share sheet opened.")}catch(error){if((error as Error).name!=="AbortError")setFeedback("Sharing did not complete. Download the PNG or copy the result link instead.")}};
  return <div className="share-scrim" role="presentation" onMouseDown={event=>event.target===event.currentTarget&&onClose()}><div className="share-dialog" role="dialog" aria-modal="true" aria-labelledby="share-title" ref={dialogRef}><div className="share-dialog-head"><div><span className="kicker">SHARE RESULT</span><h2 id="share-title">Your result card</h2></div><button ref={closeRef} className="share-close" onClick={onClose} aria-label="Close share result">×</button></div><div className="share-dialog-grid"><ShareCard src={src} title={config.en}/><div className="share-controls"><p>Preview contains only your snapshot, up to two directions and three task-preference signals.</p><button className="button primary" disabled={!blob||busy} onClick={download}>Download PNG</button>{canFileShare?<button className="button outline" disabled={!blob||busy} onClick={share}>Share image</button>:<button className="button outline" disabled={!blob||busy} onClick={copy}>Copy link</button>}<button className="button ghost" onClick={onClose}>Close</button>{!canFileShare&&!busy&&<small>Image sharing is not supported in this browser. Download the card or copy the result link.</small>}<div className={feedback.includes("not")||feedback.includes("could not")?"share-feedback error":"share-feedback"} role="status" aria-live="polite">{feedback}</div></div></div></div></div>;
}

function MultiChoice({options,selected,onChange,max}:{options:string[];selected:string[];onChange:(value:string)=>void;max?:number}){
  return <div className="context-options multi-options">{options.map(option=>{const disabled=!!max&&selected.length>=max&&!selected.includes(option);return <button key={option} disabled={disabled} className={selected.includes(option)?"selected":""} aria-pressed={selected.includes(option)} onClick={()=>onChange(option)}><span>{selected.includes(option)?"✓":""}</span><b>{option}</b></button>})}</div>;
}

function SourceLink({role}:{role:Role}){
  return <a className="official-role-link" href={role.officialSourceUrl} target="_blank" rel="noreferrer"><span>Official source · {role.company}</span><b>{role.officialRoleTitle}</b><small>Checked {role.statusCheckedDate} ↗</small></a>;
}

export default function WorkstyleExplorer({goHome,goRoles,goCompare}:{goHome:()=>void;goRoles:()=>void;goCompare:(ids:string[])=>void}){
  const [phase,setPhase]=useState<Phase>("intro");const [step,setStep]=useState(0);const [state,setState]=useState<ExplorerState>(emptyState);const [shareOpen,setShareOpen]=useState(false);const [activeTab,setActiveTab]=useState("direction");const [motion,setMotion]=useState<"forward"|"back">("forward");const hydrated=useRef(false);const headingRef=useRef<HTMLHeadingElement>(null);
  useEffect(()=>{try{const params=new URLSearchParams(location.search);const encoded=params.get("workstyle");const saved=localStorage.getItem(STORAGE_KEY);if(encoded&&/^[ABC]{6}$/.test(encoded)){setState({...emptyState,target:params.get("target")||"Unsure",scenarioAnswers:encoded.split("") as AnswerKey[]});setPhase("result")}else if(saved){const parsed=JSON.parse(saved);setState({...emptyState,...parsed.state});setStep(parsed.step||0);setPhase(parsed.phase||"intro")}}catch{}finally{hydrated.current=true}},[]);
  useEffect(()=>{if(!hydrated.current)return;try{localStorage.setItem(STORAGE_KEY,JSON.stringify({state,step,phase}))}catch{}},[state,step,phase]);
  useEffect(()=>{window.scrollTo({top:0,left:0,behavior:"auto"});const timer=window.setTimeout(()=>headingRef.current?.focus({preventScroll:true}),40);return()=>window.clearTimeout(timer)},[phase,step]);
  const result=useMemo(()=>state.scenarioAnswers.length===6?resultForAnswers(state.scenarioAnswers):null,[state.scenarioAnswers]);
  const chooseSingle=(key:keyof ExplorerState,value:string)=>setState(current=>({...current,[key]:value}));
  const toggle=(key:"informationGaps"|"expectations"|"preparation",value:string)=>setState(current=>{const selected=current[key];const exclusive=value==="I am not sure"||value==="I have not started preparing";return {...current,[key]:selected.includes(value)?selected.filter(item=>item!==value):exclusive?[value]:[...selected.filter(item=>item!=="I am not sure"&&item!=="I have not started preparing"),value]}});
  const toggleInformationGap=(value:string)=>setState(current=>{const selected=current.informationGaps;if(selected.includes(value))return {...current,informationGaps:selected.filter(item=>item!==value)};if(selected.length>=3)return current;return {...current,informationGaps:[...selected,value]}});
  const chooseScenario=(index:number,key:AnswerKey)=>setState(current=>{const next=[...current.scenarioAnswers];next[index]=key;return {...current,scenarioAnswers:next}});
  const valid=step===0?!!state.careerStage:step===1?!!state.target:step===2?state.informationGaps.length>0:step<9?!!state.scenarioAnswers[step-3]:step===9?state.expectations.length>0:state.preparation.length>0;
  const next=()=>{if(!valid)return;setMotion("forward");if(step<10)setStep(step+1);else{setPhase("result");history.replaceState({},"",resultUrl(state))}};
  const back=()=>{setMotion("back");if(step)setStep(step-1);else setPhase("intro")};
  const reset=()=>{localStorage.removeItem(STORAGE_KEY);const url=new URL(location.href);url.searchParams.delete("workstyle");url.searchParams.delete("target");history.replaceState({},"",url);setState(emptyState);setStep(0);setPhase("intro");setShareOpen(false)};
  useEffect(()=>{if(phase!=="questions")return;const handler=(event:KeyboardEvent)=>{if(event.target instanceof HTMLInputElement||event.target instanceof HTMLTextAreaElement||event.target instanceof HTMLSelectElement)return;const number=Number(event.key);if(number>=1&&number<=9){const buttons=document.querySelectorAll<HTMLButtonElement>(".question-panel .answer-option:not(:disabled)");buttons[number-1]?.click()}else if(event.key==="Enter"&&valid){event.preventDefault();next()}};window.addEventListener("keydown",handler);return()=>window.removeEventListener("keydown",handler)},[phase,step,valid,state]);

  if(phase==="intro")return <div className="workstyle-shell intro-screen page-enter"><div className="intro-copy"><span className="kicker">QUANT CAREER REALITY CHECK</span><h1 ref={headingRef} tabIndex={-1}>Connect your context, work preferences and target-role assumptions.</h1><p>Eleven lightweight questions combine your exploration stage, six work scenarios and official JD evidence. The result identifies directions and assumptions worth investigating—not ability or future performance.</p><div className="time-note">About 4–5 minutes · 11 questions · evidence-led</div><div className="intro-actions"><button className="button primary" onClick={()=>setPhase("questions")}>Start the Reality Check →</button><button className="button outline" onClick={goRoles}>Explore verified roles</button></div></div><RoleTranslationMap/></div>;

  if(phase==="questions"){
    const scenarioIndex=step-3;const scenario=scenarioIndex>=0&&scenarioIndex<6?scenarios[scenarioIndex]:null;const section=step<3?"Context":step<9?"Workstyle":"Reality Gap";const remaining=Math.max(1,Math.ceil((10-step)*.38));
    const stageMeta=[{title:"Just discovering quant",sub:"Recently heard about quant careers.",icon:"compass"},{title:"Comparing roles",sub:"Exploring differences between role families.",icon:"compare"},{title:"Target role, not preparing yet",sub:"A direction is in mind; preparation has not started.",icon:"target"},{title:"Preparing to apply",sub:"Actively getting ready for applications.",icon:"briefcase"},{title:"Applied or interviewed",sub:"Already engaged with a recruitment process.",icon:"message"},{title:"Relevant experience",sub:"Internship or work exposure in a related area.",icon:"badge"}];
    const optionButton=({visibleTitle,subtitle,icon,storedValue,selected,onClick,index,disabled=false}:{visibleTitle:string;subtitle?:string;icon:string;storedValue:string;selected:boolean;onClick:()=>void;index:number;disabled?:boolean})=><button key={storedValue} type="button" className={`answer-option ${selected?"selected":""}`} aria-pressed={selected} disabled={disabled} data-value={storedValue} onClick={onClick}><LineIcon name={icon}/><span className="answer-copy"><b>{visibleTitle}</b>{subtitle&&<small>{subtitle}</small>}</span><i>{selected?"✓":index+1}</i></button>;
    return <div className="scenario-shell"><div className="questionnaire-chrome"><div className="questionnaire-meta"><button className="bare" onClick={back}>← Back</button><div><b>{section}</b><small>Question {step+1} of 11 · about {remaining} min remaining</small></div><button className="bare" onClick={reset}>Restart</button></div><div className="segmented-progress" aria-label={`Question ${step+1} of 11`}><div className="progress-group context" aria-label="Context questions">{[0,1,2].map(i=><span key={i} className={i<=step?"filled":""}/>)}</div><div className="progress-group workstyle" aria-label="Workstyle questions">{[3,4,5,6,7,8].map(i=><span key={i} className={i<=step?"filled":""}/>)}</div><div className="progress-group gap" aria-label="Reality Gap questions">{[9,10].map(i=><span key={i} className={i<=step?"filled":""}/>)}</div></div></div><section className={`scenario-card integrated-question ${scenario?"with-scene":""}`}><div key={step} className={`question-panel question-${motion}`}>{scenario&&<ScenarioVisual index={scenarioIndex}/>}<div className="question-content"><span className="kicker">{section.toUpperCase()}</span>
      {step===0&&<><h1 ref={headingRef} tabIndex={-1}>Where are you currently in your quant-career exploration?</h1><div className="context-options">{careerStageOptions.map((option,index)=>optionButton({visibleTitle:stageMeta[index].title,subtitle:stageMeta[index].sub,icon:stageMeta[index].icon,storedValue:option,selected:state.careerStage===option,onClick:()=>chooseSingle("careerStage",option),index}))}</div></>}
      {step===1&&<><h1 ref={headingRef} tabIndex={-1}>What role are you currently considering?</h1><p className="question-help">Used only for evidence comparison. It never changes the Workstyle signals.</p><div className="context-options">{targetRoleOptions.map((option,index)=>optionButton({visibleTitle:option,icon:index===0?"compass":index===1?"market":index===2?"research":"code",storedValue:option,selected:state.target===option,onClick:()=>chooseSingle("target",option),index}))}</div></>}
      {step===2&&<><h1 ref={headingRef} tabIndex={-1}>What is currently hardest for you to understand?</h1><p className="question-help">Select up to three. These signals only prioritise your next actions.</p><div className="selection-limit" role="status" aria-live="polite"><b>{state.informationGaps.length} of 3 selected</b>{state.informationGaps.length>=3&&<span>Choose up to three. Remove one selection to choose another.</span>}</div><div className="context-options compact-options">{informationGapOptions.map((option,index)=>{const selected=state.informationGaps.includes(option);return optionButton({visibleTitle:informationGapTitles[index],icon:index===5?"briefcase":index===6?"target":index===7?"shield":"research",storedValue:option,selected,onClick:()=>toggleInformationGap(option),index,disabled:state.informationGaps.length>=3&&!selected})})}</div></>}
      {scenario&&<><h1 ref={headingRef} tabIndex={-1}>{scenario.prompt}</h1><p className="question-help">Choose the activity you would most like to investigate. Letters are shuffled signals, not fixed dimensions.</p><div className="scenario-options">{scenario.options.map((option,index)=><button key={option.key} className={`answer-option ${state.scenarioAnswers[scenarioIndex]===option.key?"selected":""}`} aria-pressed={state.scenarioAnswers[scenarioIndex]===option.key} onClick={()=>chooseScenario(scenarioIndex,option.key)}><span>{option.key}</span><b>{option.label}</b><i>{state.scenarioAnswers[scenarioIndex]===option.key?"✓":index+1}</i></button>)}</div></>}
      {step===9&&<><h1 ref={headingRef} tabIndex={-1}>Which tasks do you currently expect your target role to involve most?</h1><div className="compact-chip-grid"><MultiChoice options={expectationOptions} selected={state.expectations} onChange={value=>toggle("expectations",value)}/></div></>}
      {step===10&&<><h1 ref={headingRef} tabIndex={-1}>What are you currently spending most of your preparation time on?</h1><div className="compact-chip-grid"><MultiChoice options={preparationOptions} selected={state.preparation} onChange={value=>toggle("preparation",value)}/></div></>}
      </div></div><div className="scenario-actions"><small>Press 1–9 to choose · Enter to continue</small><button className="button primary" disabled={!valid} onClick={next}>{step===10?"See directions worth exploring":"Continue"} →</button></div></section></div>;
  }

  if(!result)return null;const config=result.config;const targetFamily=roleFamilyFor(state.target,config);const familyEvidence=roles.filter(role=>role.normalisedRoleFamily===targetFamily);const selected=evidenceRoles(config,state.target);const actual=advertisedTasks(familyEvidence);const examples=distinctFirmExamples(selected);const supported=state.expectations.filter(item=>actual.includes(item));const needsVerification=state.expectations.filter(item=>item!=="I am not sure"&&!actual.includes(item));const varied=fingerprintTaxonomy.filter(item=>{const count=familyEvidence.filter(role=>item.pattern.test(`${role.responsibilities} ${role.requiredSkills}`)).length;return count>0&&count<familyEvidence.length}).map(item=>item.label).slice(0,3);const notStated=taskTaxonomy.filter(item=>!item.pattern.test(familyEvidence.map(role=>`${role.responsibilities} ${role.requiredSkills}`).join(" "))).map(item=>item.label).slice(0,3);const prep=preparationAnalysis(state,familyEvidence);const repeatedPrep=preparationTaxonomy.filter(item=>familyEvidence.filter(role=>item.pattern.test(`${role.responsibilities} ${role.requiredSkills}`)).length>=2).map(item=>item.label).slice(0,4);const actions=nextActions(state,config,selected,actual);const link=resultUrl(state);const allTied=config.directions.length===3;const displayDirections=allTied?[]:config.directions.slice(0,2);const preferenceSignals=state.scenarioAnswers.map((answer,index)=>scenarios[index].options.find(item=>item.key===answer)?.label||"").filter(Boolean).slice(0,3);const realityGap=state.informationGaps[0]?visibleInformationGap(state.informationGaps[0]):needsVerification[0]||"Verify how this role varies by company.";const alignment=targetAlignment({target:state.target,directions:config.directions,primary:config.primary});const contextLine=`${stageContext(state.careerStage)} · ${state.target&&state.target!=="Unsure"?`currently considering ${state.target}`:"target role not selected"}`;

  return <div className={`workstyle-results result-theme-${config.illustration} page-enter`}><section className="result-dashboard"><div className="result-summary"><span className="kicker">YOUR RESULT</span><h1 ref={headingRef} tabIndex={-1}>Your Reality Check</h1><p className="result-context-line">{contextLine}</p><div className="workstyle-summary-card"><div><small>WORKSTYLE SNAPSHOT</small><h2>{config.en}</h2><p>{config.description}</p></div><div className="workstyle-bars compact-bars">{(["research","decision","systems"] as const).map(key=><div key={key}><div><b>{dimensions[key].label}</b><span>{result.scores[key]/2} {result.scores[key]===2?"signal":"signals"}</span></div><i><span style={{width:`${Math.max(4,result.scores[key]/12*100)}%`,background:dimensions[key].color}}/></i></div>)}</div><small className="signal-disclaimer">Preference signals from six work scenarios—not measured ability.</small></div>{allTied?<div className="tie-comparison"><b>Balanced task signals</b><span>No single task direction stands out from these six scenarios. Use your target role, current information gap and a small real-work experiment to narrow further.</span></div>:<div className="tendency-pills"><small>{displayDirections.length===1?"Direction worth exploring first":"Directions worth exploring first"}</small>{displayDirections.map(direction=><span key={direction}>{direction}</span>)}</div>}<div className={`target-alignment ${alignment.kind}`}><small>TARGET ALIGNMENT</small><p>{alignment.text}</p></div><div className="result-hero-actions"><button className="button primary" onClick={()=>setShareOpen(true)}>Share Result</button><button className="button outline" onClick={()=>document.getElementById("result-evidence")?.scrollIntoView({behavior:"smooth"})}>View evidence behind this result</button></div></div><div className="result-visual"><ResultArt kind={config.illustration}/><div className="prominent-gap"><small>ONE REALITY GAP TO CHECK</small><b>{realityGap}</b><span>Use official role wording and one practitioner perspective before treating this assumption as settled.</span></div></div><div className="above-fold-actions"><span className="kicker">THREE NEXT ACTIONS</span><div className="next-three">{actions.map((action,index)=><article key={action}><span>0{index+1}</span><p>{action}</p></article>)}</div></div></section><div className="diagnosis-note"><b>This is a Current Workstyle Snapshot, not a personality diagnosis or a career verdict.</b><span>It summarises task-preference choices and does not establish ability, suitability or future performance.</span></div>

    <section className="evidence-disclosure" id="result-evidence"><div className="result-tabs" role="tablist" aria-label="Result evidence sections">{[["direction","Workstyle & target"],["reality","Reality Gap"],["preparation","Preparation Gap"],["roles","Role evidence"],["method","Methodology"]].map(([id,label])=><button key={id} role="tab" aria-selected={activeTab===id} className={activeTab===id?"active":""} onClick={()=>setActiveTab(id)}>{label}</button>)}</div>
      {activeTab==="direction"&&<div className="result-tab-panel" role="tabpanel"><div className="section-index">LAYER 1 · WORKSTYLE SNAPSHOT</div><h2>{config.en}</h2><p className="section-intro">Preference signals from six work scenarios—not measured ability.</p><div className="workstyle-bars">{(["research","decision","systems"] as const).map(key=><div key={key}><div><b>{dimensions[key].label}</b><span>{result.scores[key]/2} {result.scores[key]===2?"signal":"signals"}</span></div><i><span style={{width:`${Math.max(4,result.scores[key]/12*100)}%`,background:dimensions[key].color}}/></i></div>)}</div><div className="section-index">LAYER 2 · TARGET ALIGNMENT</div><div className={`target-alignment ${alignment.kind}`}><p>{alignment.text}</p></div><div className="context-summary"><article><small>CURRENT EXPLORATION STAGE</small><h3>{state.careerStage||"Not included in shared link"}</h3><small>TARGET ROLE</small><h3>{state.target||"Not included in shared link"}</h3></article><article><small>HARDEST INFORMATION TO UNDERSTAND</small><div className="summary-chips">{state.informationGaps.map(item=><span key={item}>{visibleInformationGap(item)}</span>)}</div></article></div></div>}
      {activeTab==="reality"&&<div className="result-tab-panel" role="tabpanel"><div className="section-index">LAYER 3 · REALITY GAP</div><h2>Compare your expectation with reviewed {targetFamily} descriptions</h2><div className="current-input"><small>YOUR CURRENT EXPECTATION</small><p>{state.expectations.join(" · ")||"Not included in shared link"}</p></div><div className="gap-analysis evidence-status-grid"><article className="aligned"><small>SUPPORTED BY REVIEWED JDS</small>{supported.length?<ul>{supported.map(item=><li key={item}>{item}</li>)}</ul>:<p>No direct label-level match established.</p>}</article><article className="variation"><small>VARIES BY FIRM</small><ul>{varied.map(item=><li key={item}>{item}</li>)}</ul></article><article className="prepare"><small>NOT STATED IN REVIEWED EVIDENCE</small>{notStated.length?<ul>{notStated.map(item=><li key={item}>{item}</li>)}</ul>:<p>No further taxonomy item is absent across every reviewed role.</p>}</article><article className="verify"><small>WHAT TO VERIFY NEXT</small>{needsVerification.length?<ul>{needsVerification.map(item=><li key={item}>{item} — not found in the reviewed wording; absence is not evidence that it never occurs.</li>)}</ul>:<p>Verify team-level time allocation and lived day-to-day work with a practitioner.</p>}</article></div></div>}
      {activeTab==="preparation"&&<div className="result-tab-panel" role="tabpanel"><div className="section-index">LAYER 4 · PREPARATION GAP</div><h2>Compare your preparation with the relevant reviewed JDs</h2><div className="current-input"><small>CURRENT PREPARATION PRIORITY</small><p>{state.preparation.join(" · ")||"Not included in shared link"}</p></div><div className="gap-analysis preparation-gap-grid"><article className="aligned"><small>REPEATEDLY MENTIONED IN RELEVANT JDS</small><p>{repeatedPrep.join(" · ")||"No repeated taxonomy-level pattern established."}</p></article><article className="prepare"><small>A POSSIBLE MISSING AREA</small><p>{prep.possible[0]||"Use the exact company requirements to identify a concrete area."}</p></article><article className="variation"><small>YOUR CURRENTLY RELEVANT PREPARATION</small><p>{prep.relevant.join(" · ")||"No direct wording match established yet."}</p></article><article className="verify"><small>VERIFY FOR THE SPECIFIC FIRM</small><p>Check degree, grades, graduation timing, working rights, live status and preferred-versus-required wording in the exact official source.</p></article></div></div>}
      {activeTab==="roles"&&<div className="result-tab-panel" role="tabpanel"><h2>Company-specific evidence from the same role family</h2><p className="variation-statement">Among the reviewed sources, a title is a starting point—not a universal definition.</p><div className="firm-variation-grid">{examples.map(role=><article key={role.id}><span>{role.company}</span><h3>{role.officialRoleTitle}</h3><dl><dt>Location</dt><dd>{role.location}</dd><dt>Level</dt><dd>{role.level}</dd><dt>Application status</dt><dd>{role.applicationStatus}. {role.statusCaveat}</dd><dt>Main advertised tasks</dt><dd>{role.responsibilities}</dd></dl><SourceLink role={role}/></article>)}</div><button className="button outline compare-direct" onClick={()=>goCompare(examples.map(role=>role.id))}>Compare these roles across firms →</button></div>}
      {activeTab==="method"&&<div className="result-tab-panel" role="tabpanel"><h2>How the snapshot was produced</h2><div className="answer-trace">{state.scenarioAnswers.map((answer,index)=>{const option=scenarios[index].options.find(item=>item.key===answer)!;return <article key={scenarios[index].id}><span>0{index+1}</span><div><b>{scenarios[index].prompt}</b><p>“{option.label}”</p></div></article>})}</div><div className="workstyle-bars">{(["research","decision","systems"] as const).map(key=><div key={key}><div><b>{dimensions[key].label}</b><span>{result.scores[key]} signal points</span></div><i><span style={{width:`${Math.max(4,result.scores[key]/12*100)}%`,background:dimensions[key].color}}/></i></div>)}</div><p className="rule-note">Each scenario adds two points to its configured dimension. The A/B/C order changes across questions. This heuristic has not been psychometrically validated.</p><p className="target-exclusion">Target role—<b>{state.target||"Not included in shared link"}</b>—did not participate in the calculation.</p></div>}
    </section><div className="result-footer-actions"><button className="button outline" onClick={reset}>Retake Reality Check</button><button className="button outline" onClick={goRoles}>Explore verified roles</button><button className="bare" onClick={goHome}>Back to home</button></div><ShareModal open={shareOpen} onClose={()=>setShareOpen(false)} config={config} directions={displayDirections} signals={preferenceSignals} link={link} resultId={result.id}/></div>;
}
