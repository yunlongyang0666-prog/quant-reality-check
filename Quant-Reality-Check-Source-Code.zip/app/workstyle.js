// @ts-check

/** @typedef {"research"|"decision"|"systems"} Dimension */
/** @typedef {"A"|"B"|"C"} AnswerKey */

export const dimensions = {
  research: { label:"Research iteration", short:"Research", color:"#7C6CF2" },
  decision: { label:"Real-time decision", short:"Decision", color:"#FFB454" },
  systems: { label:"Systems building", short:"Systems", color:"#31C7B5" },
};

export const careerStageOptions = [
  "I have only recently heard about quant careers.",
  "I am comparing different roles.",
  "I have a target role but have not started preparing.",
  "I am preparing to apply.",
  "I have applied or interviewed.",
  "I have relevant internship or work experience.",
];

export const targetRoleOptions = ["Unsure","Quantitative Trading","Quantitative Research","Software / Quantitative Engineering","Another quant-related role"];
export const informationGapOptions = ["What different roles actually do day to day","Mathematics and programming requirements","Differences between Trader, Researcher and Engineering","Which role fits my interests and academic background","Interview preparation priorities","Recruitment stages and timelines","Eligibility, location and working-right requirements","Which information sources are current and trustworthy"];
export const expectationOptions = ["Analysing datasets","Developing and validating models","Making real-time risk decisions","Monitoring markets","Writing production software","Optimising latency and system performance","Building data pipelines","Pricing, liquidity or execution work","Communicating research or trading decisions","I am not sure"];
export const preparationOptions = ["Probability and mathematics","Statistics and machine learning","Python and data analysis","Algorithms and data structures","C++ and systems programming","Market knowledge","Mental maths or trading games","Interview questions","Networking and company research","I have not started preparing"];

/** @type {{id:string,prompt:string,options:{key:AnswerKey,dimension:Dimension,label:string}[]}[]} */
export const scenarios = [
  { id:"strategy-breaks", prompt:"A strategy that used to work suddenly stops performing. What would you rather do first?", options:[
    {key:"A",dimension:"research",label:"Analyse the data and test possible causes one by one."},
    {key:"B",dimension:"decision",label:"Control the risk first and make a reversible decision."},
    {key:"C",dimension:"systems",label:"Check the data, latency and system pipeline."},
  ]},
  { id:"free-afternoon", prompt:"You get a completely free afternoon. Which activity sounds most absorbing?", options:[
    {key:"A",dimension:"systems",label:"Optimise a backtesting or data system."},
    {key:"B",dimension:"research",label:"Investigate an unusual pattern in a dataset."},
    {key:"C",dimension:"decision",label:"Join a market decision-making simulation."},
  ]},
  { id:"feedback", prompt:"Which kind of feedback feels most satisfying?", options:[
    {key:"A",dimension:"decision",label:"The market immediately reveals the quality of a decision."},
    {key:"B",dimension:"systems",label:"A measurable improvement in system performance."},
    {key:"C",dimension:"research",label:"A research conclusion that holds up under challenge."},
  ]},
  { id:"uncertain-outcome", prompt:"When an outcome is uncertain, which response feels most natural to explore?", options:[
    {key:"A",dimension:"research",label:"Design another experiment to narrow the uncertainty."},
    {key:"B",dimension:"systems",label:"Reproduce the issue and debug it layer by layer."},
    {key:"C",dimension:"decision",label:"Make a reversible choice with the information available."},
  ]},
  { id:"achievement", prompt:"Which result would give you the strongest sense of progress?", options:[
    {key:"A",dimension:"systems",label:"A reliable system that keeps running over time."},
    {key:"B",dimension:"decision",label:"A timely judgement with risk kept under control."},
    {key:"C",dimension:"research",label:"A model supported by clear evidence."},
  ]},
  { id:"learning", prompt:"Which learning activity is easiest for you to stay engaged with?", options:[
    {key:"A",dimension:"decision",label:"Probability, market mechanisms and risk decisions."},
    {key:"B",dimension:"research",label:"Statistics, machine learning and research methods."},
    {key:"C",dimension:"systems",label:"Algorithms, concurrency, systems and performance engineering."},
  ]},
];

const commonCannotProve = "This snapshot cannot prove ability, career suitability, personality type or future performance.";

export const resultConfigs = {
  "signal-explorer": {
    en:"Signal Explorer", zh:"信号探索者", description:"You currently lean toward patient investigation: finding patterns, forming hypotheses and testing what survives the evidence.",
    primary:"research", secondary:null, directions:["Quantitative Research"], cannotProve:commonCannotProve,
    realityCheck:"Quantitative Research role descriptions in this sample also ask for strong programming and implementation—not mathematics alone.",
    actions:["Compare the Jane Street and Citadel Securities Quantitative Research internship descriptions.","Spend 60 minutes testing one hypothesis on a small public dataset and record what would falsify it.","Ask one researcher or student how often research ideas become production code within their team."],
    evidenceQueries:[{company:"Jane Street",title:"Quantitative Researcher"},{company:"Citadel Securities",title:"Quantitative Research Analyst"},{company:"DRW",title:"Quantitative Research"},{company:"Two Sigma",title:"Quantitative Researcher"}], illustration:"signal", accent:"#7C6CF2", accent2:"#5F8DFF", background:"#11142E",
  },
  "market-navigator": {
    en:"Market Navigator", zh:"市场领航者", description:"You currently lean toward making bounded decisions under uncertainty and learning from immediate feedback.",
    primary:"decision", secondary:null, directions:["Quantitative Trading"], cannotProve:commonCannotProve,
    realityCheck:"Among the reviewed roles, trading can include data analysis, research, model use, Python and strategy testing—not only fast execution.",
    actions:["Read the Optiver and Citadel Securities trading internship descriptions side by side.","Run a 45-minute decision simulation: define a reversible choice, a risk limit and the signal that would change your mind.","Verify one live application status and eligibility condition on the official role page."],
    evidenceQueries:[{company:"Optiver",title:"Quantitative Trading"},{company:"Citadel Securities",title:"Quantitative Trading"},{company:"IMC Trading",title:"Trading Internship"},{company:"DRW",title:"Quantitative Trading"}], illustration:"market", accent:"#FFB454", accent2:"#FF766B", background:"#281A18",
  },
  "systems-builder": {
    en:"Systems Builder", zh:"系统构筑者", description:"You currently lean toward turning ideas into dependable systems through debugging, performance work and careful implementation.",
    primary:"systems", secondary:null, directions:["Software Engineering"], cannotProve:commonCannotProve,
    realityCheck:"Software roles in the reviewed firms are often embedded directly in trading and research workflows rather than isolated support work.",
    actions:["Compare the Citadel Securities and DRW software internship descriptions.","Profile or debug one small data pipeline and document one measurable reliability or speed improvement.","Ask one engineer which trading or research users depend on the system they build."],
    evidenceQueries:[{company:"Citadel Securities",title:"Software Engineer"},{company:"DRW",title:"Software Developer"},{company:"Susquehanna (SIG)",title:"Trading System Engineering"},{company:"Two Sigma",title:"Software Engineering"}], illustration:"systems", accent:"#31C7B5", accent2:"#4C8DFF", background:"#0B2427",
  },
  "strategy-synthesizer": {
    en:"Strategy Synthesizer", zh:"策略融合者", description:"You currently combine research iteration with real-time judgement: test the idea, then decide how to act under uncertainty.",
    primary:"research", secondary:"decision", directions:["Quantitative Research","Quantitative Trading"], cannotProve:commonCannotProve,
    realityCheck:"Some reviewed trading internships explicitly include quantitative research, signals, machine learning and backtesting; the title alone does not define the task mix.",
    actions:["Read the SIG Quantitative Systematic Trading and IMC Trading internship descriptions.","Backtest one simple rule, then write the risk condition that would stop you using it in a live simulation.","Ask a trader or researcher where responsibility shifts from model evidence to real-time judgement."],
    evidenceQueries:[{company:"Susquehanna (SIG)",title:"Quantitative Systematic Trading"},{company:"IMC Trading",title:"Trading Internship"},{company:"DRW",title:"Quantitative Trading"}], illustration:"synth", accent:"#9B7CFF", accent2:"#FF9C54", background:"#22172C",
  },
  "model-to-market-builder": {
    en:"Model-to-Market Builder", zh:"模型落地者", description:"You currently combine research depth with implementation: understand the model, then make it robust enough to use.",
    primary:"research", secondary:"systems", directions:["Quantitative Research","Software Engineering"], cannotProve:commonCannotProve,
    realityCheck:"Reviewed research roles can extend from modelling and backtesting into high-performance or live implementation.",
    actions:["Compare the Optiver Graduate Quantitative Researcher and Citadel Securities Research Analyst descriptions.","Take one small model and build a repeatable input → test → output pipeline around it.","Ask one practitioner what usually breaks between a research notebook and a production workflow."],
    evidenceQueries:[{company:"Optiver",title:"Graduate Quantitative Researcher"},{company:"Citadel Securities",title:"Quantitative Research Analyst"},{company:"DRW",title:"Quantitative Research"}], illustration:"bridge", accent:"#568BFF", accent2:"#31C7B5", background:"#0D1D32",
  },
  "execution-architect": {
    en:"Execution Architect", zh:"执行架构者", description:"You currently combine rapid, risk-aware judgement with the engineering discipline needed for reliable execution.",
    primary:"decision", secondary:"systems", directions:["Quantitative Trading","Software Engineering"], cannotProve:commonCannotProve,
    realityCheck:"Trading decisions depend on data and systems, while several engineering roles are built directly around trading-strategy development.",
    actions:["Compare the SIG Trading System Engineering and Citadel Securities Quantitative Trading descriptions.","Build a tiny event-driven simulation with a decision rule, latency assumption and failure fallback.","Ask a trader or engineer which system constraint most changes real-time decisions."],
    evidenceQueries:[{company:"Susquehanna (SIG)",title:"Trading System Engineering"},{company:"Citadel Securities",title:"Quantitative Trading"},{company:"DRW",title:"Quantitative Trading"}], illustration:"execution", accent:"#FF9C54", accent2:"#31C7B5", background:"#251C17",
  },
  "open-explorer": {
    en:"Open Explorer", zh:"开放探索者", description:"Your answers are currently spread across research, decisions and systems—useful evidence to explore all three before narrowing.",
    primary:null, secondary:null, directions:["Quantitative Research","Quantitative Trading","Software Engineering"], cannotProve:commonCannotProve,
    realityCheck:"The reviewed firms organise overlapping work differently, so keeping multiple directions open can be a rational next step rather than a lack of direction.",
    actions:["Choose one official JD from each role family and highlight the tasks you would most like to try.","Run three 30-minute task samples this week: analyse data, make a bounded decision and debug a small system.","Ask one practitioner which role boundary surprised them after starting work."],
    evidenceQueries:[{company:"Two Sigma",title:"Quantitative Researcher"},{company:"Citadel Securities",title:"Quantitative Trading"},{company:"DRW",title:"Software Developer"}], illustration:"prism", accent:"#8A87A8", accent2:"#6CAEA6", background:"#171B27",
  },
};

/** @param {AnswerKey[]} answers */
export function scoreAnswers(answers) {
  const scores = { research:0, decision:0, systems:0 };
  answers.forEach((answer,index) => {
    const option = scenarios[index]?.options.find(item=>item.key===answer);
    if (option) scores[option.dimension] += 2;
  });
  return scores;
}

/** @param {{research:number,decision:number,systems:number}} scores */
export function classifyScores(scores) {
  const ranked = Object.entries(scores).sort((a,b)=>b[1]-a[1]);
  const spread = ranked[0][1] - ranked[2][1];
  if (spread <= 2) return "open-explorer";
  if (ranked[0][1] - ranked[1][1] <= 2) {
    const pair = new Set([ranked[0][0],ranked[1][0]]);
    if (pair.has("research") && pair.has("decision")) return "strategy-synthesizer";
    if (pair.has("research") && pair.has("systems")) return "model-to-market-builder";
    return "execution-architect";
  }
  return ranked[0][0] === "research" ? "signal-explorer" : ranked[0][0] === "decision" ? "market-navigator" : "systems-builder";
}

/** @param {AnswerKey[]} answers */
export function resultForAnswers(answers) {
  const scores = scoreAnswers(answers);
  const id = classifyScores(scores);
  return { id, scores, config: resultConfigs[id] };
}
