// @ts-check

export function stageContext(stage){
  if(/recently heard/i.test(stage))return "Early-stage explorer";
  if(/comparing/i.test(stage))return "Comparing roles";
  if(/target role/i.test(stage))return "Target role selected";
  if(/preparing to apply/i.test(stage))return "Preparing to apply";
  if(/applied or interviewed/i.test(stage))return "Applied or interviewed";
  if(/experience/i.test(stage))return "Relevant experience";
  return "Exploring quant careers";
}

export function targetFamily(target){
  if(target==="Software / Quantitative Engineering")return "Software Engineering";
  if(target==="Quantitative Research"||target==="Quantitative Trading")return target;
  return null;
}

export function targetAlignment({target,directions,primary}){
  const family=targetFamily(target);
  if(!family)return {kind:"unsure",text:directions.length===1?"You have not selected a target role yet. Start with the direction above, then compare it with one adjacent role family before narrowing.":"You have not selected a target role yet. Start by comparing the two role families that most closely reflect your task preferences."};
  if(!primary&&directions.length===3)return {kind:"balanced",text:`Your current target is ${family}. The six workstyle scenarios were balanced, so this target is used to select relevant evidence—not to force a Workstyle winner.`};
  if(directions.includes(family))return {kind:"aligned",text:`Your current target is ${family}, and your workstyle responses also emphasised ${primary==="research"?"research iteration":primary==="decision"?"real-time decisions":primary==="systems"?"systems building":"a balanced mix of task preferences"}.`};
  const emphasis=primary==="research"?"research iteration":primary==="decision"?"real-time decisions":primary==="systems"?"systems building":"several task directions";
  return {kind:"adjacent",text:`Your current target is ${family}, while your responses showed stronger interest in ${emphasis}. This is not a mismatch verdict. Compare the daily tasks of both role families before narrowing.`};
}

export function actionPlan({careerStage,informationGaps,expectations,preparation}){
  const stage=/recently heard/i.test(careerStage)?"early":/preparing to apply/i.test(careerStage)?"preparing":/applied or interviewed/i.test(careerStage)?"applied":/comparing/i.test(careerStage)?"comparing":"experienced";
  const gap=informationGaps[0]||"";
  const gapType=/day to day/i.test(gap)?"day-to-day":/Mathematics|programming|requirements/i.test(gap)?"requirements":/Recruitment|timeline/i.test(gap)?"timeline":/Interview/i.test(gap)?"interview":/Eligibility|location|working-right/i.test(gap)?"eligibility":/sources|trustworthy/i.test(gap)?"sources":"role-differences";
  const preparationType=preparation.includes("I have not started preparing")?"starter":expectations.includes("I am not sure")?"assumption":preparation.length?"compare-preparation":"experiment";
  return {stage,gapType,preparationType};
}
