import type { RoleFamily } from "./data";

export const activityOptions = [
  "Analysing datasets and testing hypotheses",
  "Building and validating statistical or ML models",
  "Making fast decisions under uncertainty",
  "Developing and backtesting trading strategies",
  "Building reliable or high-performance software systems",
  "Improving data pipelines, infrastructure or system performance",
  "Communicating reasoning and collaborating across technical teams",
  "Not sure yet",
] as const;

export const skillOptions = ["Python","C++","Java","Statistics / probability","Machine learning","Data analysis","Algorithms / data structures","Systems / concurrency","Finance / markets","None yet"] as const;

export const explorationRules: Record<RoleFamily,{activities:string[];skills:string[];evidenceRoleIds:string[]}> = {
  "Quantitative Research": {
    activities:[activityOptions[0],activityOptions[1],activityOptions[3]],
    skills:["Python","Statistics / probability","Machine learning","Data analysis"],
    evidenceRoleIds:["js-research","opt-research","imc-research","akuna-research"],
  },
  "Quantitative Trading": {
    activities:[activityOptions[2],activityOptions[3]],
    skills:["Python","Statistics / probability","Finance / markets"],
    evidenceRoleIds:["js-trader","opt-trader","imc-trader","akuna-trader"],
  },
  "Software Engineering": {
    activities:[activityOptions[4],activityOptions[5]],
    skills:["Python","C++","Java","Algorithms / data structures","Systems / concurrency"],
    evidenceRoleIds:["js-swe","opt-swe","imc-swe","akuna-swe"],
  },
};

export type Answers = {
  activities:string[]; education:string; field:string; exposure:string; skills:string[];
  market:string; showEligibility:boolean; target:string; expectations:string[]; expectationText:string;
};

export const emptyAnswers: Answers = { activities:[], education:"", field:"", exposure:"", skills:[], market:"", showEligibility:true, target:"Unsure", expectations:[], expectationText:"" };

export function directionsFor(answers: Answers): RoleFamily[] {
  const families = Object.keys(explorationRules) as RoleFamily[];
  const signals = families.map(family => {
    const rule = explorationRules[family];
    const activities = answers.activities.filter(a => rule.activities.includes(a)).length;
    const skills = answers.skills.filter(s => rule.skills.includes(s)).length;
    return {family, activitySignals:activities, supportingSignals:skills};
  });
  const topActivity = Math.max(...signals.map(s=>s.activitySignals));
  if (topActivity === 0) {
    const targeted = signals.filter(s=>s.supportingSignals>0).sort((a,b)=>b.supportingSignals-a.supportingSignals);
    return targeted.length ? targeted.slice(0,2).map(s=>s.family) : ["Quantitative Research","Quantitative Trading"];
  }
  const leaders = signals.filter(s=>s.activitySignals===topActivity).sort((a,b)=>b.supportingSignals-a.supportingSignals);
  return leaders.slice(0,2).map(s=>s.family);
}
